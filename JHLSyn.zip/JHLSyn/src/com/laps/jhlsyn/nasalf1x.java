package com.laps.jhlsyn;

import com.laps.jhlsyn.pogo.FNPVars;
import com.laps.jhlsyn.pogo.HLFrame;
import com.laps.jhlsyn.pogo.HLSpeaker;
import com.laps.jhlsyn.pogo.HLState;
import com.laps.jhlsyn.pogo.LLFrame;
import com.laps.jhlsyn.pogo.ObjTemp1;
import com.laps.jhlsyn.pogo.TableRow;

public class nasalf1x {

	/*****************************************************************************/
	/** HLsyn - Version 2.2 **/
	/**                                                                         **/
	/** Copyright (c) 1993-1998 by Sensimetrics Corporation **/
	/** All rights reserved. **/
	/**                                                                         **/
	/*****************************************************************************/

	static/*
		 * nasalf1x.c - compute FNP,FNZ and nasal effected f1 (f1c.f1x)
		 * 
		 * coded by J. Erik Moore, 12/93
		 * 
		 * Modification History:
		 * 
		 * 25 Mar 1998 reb: passed f1c to FiniteBracketFNP and used it as a
		 * lower bound on the location of the root (fixes a bug that arose if
		 * f1c >> fn); made FINITE_OFFSET a float constant; in NasalPole renamed
		 * Brac_fn and Brac_fp to Brac_low and Brac_high, if bracketing fails
		 * returned a rough guess for FNP, and solve for FNP directly if K2 is
		 * sufficiently small; in NasalFirstFormant extrapolated a and b values
		 * before the first entries in the ana and anb tables (fixes problems
		 * when an is zero or just slightly above); replaced an by MAX(0, an)
		 * where appropriate. 6 Oct 1997 reb: replaced REMOVE_NASAL_POLE_ZERO by
		 * speaker.fno and REMOVE_BANDWIDTH by speaker.NasalBandwidth; replaced
		 * hard-coded constants in computation of fm, b1x. BNP by references to
		 * speaker constants; changed arguments of NasalPole, NasalFirstFormant,
		 * NasalZero (to enable swapping f1x and FNP if desired); used
		 * general-purpose Brent routine instead of FNP_zbrent (needed to swap
		 * arguments of SusceptanceSum to do this); made local routines static,
		 * moved definition of FNPVars here from hlsyn.h, introduced
		 * AN_NO_NASAL_BREAKPOINT. 21 Aug 1996 reb: in calculation of FNPvars.fp
		 * (NasalPole), replaced some hard-coded constants by references to
		 * speaker.fp_f2BreakPoint; used REMOVE_NASAL_POLE_ZERO to set FNZ, FNP
		 * when an = 0; included flavor.h 08 Aug 1996 reb: archived as version
		 * 2.2 (no changes).
		 */
	final double FINITE_OFFSET = 0.1f;
	final static double MAX_FINITE_ITERATIONS = 20;
	final static double FINITE_BRACKETED = 1;
	final static double NOT_FINITE_BRACKETED = 0;

	final static double FLT_EPSILON = 1.19209289550781250000e-7f; // este valor veio
															// do proprio codigo
															// c do programa

	/* For Brent */
	final static int ITMAX = 100; /* Max allowed iterations */
	final static double EPS = 3.0e-8f; /* Machine doubleing point precision */
	final static double FNP_TOL = 1.0e-5f; /* Root tolerance (From Dave Williams code) */

	/*****
	 * Local module function declarations
	 *****/

	// static int column2Set;

	static void SetNasals_f1x(HLFrame frame, HLSpeaker speaker, HLState state,
			LLFrame llframe) {
		if (frame.an < hlsyn.AN_NO_NASAL_BREAKPOINT) {
			/*****
			 * Nasal cavity does not connect to oral cavity. f1 is not modified
			 * by the nasals. There is no nasal pole or zero. This is done by
			 * setting them equal to one another and some arbitrary value so
			 * they cancel out.
			 *****/

			state.f1x = (state.f1c);
			state.b1x = ((float)speaker.getB1m());

			llframe.FNP = ((int) (speaker.getFno() + 0.5f));
			llframe.BNP = ((int) (speaker.getNasalBandwidth() + 0.5f));

			llframe.FNZ = (llframe.FNP);
			llframe.BNZ = (llframe.BNP);
		} else {

			// NasalFirstFormant(frame,speaker,state,state.f1x,state.b1x);
			NasalFirstFormant(frame, speaker, state);
			// NasalZero(frame, speaker, state, llframe.getFNZ(),
			// llframe.getBNZ());
			NasalZero(frame, speaker, state, llframe);
			// NasalPole(frame, speaker, state, llframe.getFNP(),
			// llframe.getBNP());
			NasalPole(frame, speaker, state, llframe);

			// llframe.setFNZ((int) (llframe.getFNZ() + 0.5f));
			// llframe.setBNZ((int) (llframe.getBNZ() + 0.5f));
			// llframe.setFNP((int) (llframe.getFNP() + 0.5f));
			// llframe.setBNP((int) (llframe.getBNP() + 0.5f));
		}
	}

	static void NasalZero(HLFrame frame, HLSpeaker speaker, HLState state,
			LLFrame llframe) {

		double pFNZ = llframe.FNZ;
		double pBNZ = llframe.BNZ;

		double fn, fm, LOverA, MmOverMn, an = (double) hlsyn
				.MAX(0.0f, frame.an);

		/*****
		 * The an to fn table is based on an assumed fno. If fno is different
		 * then the result is scaled.
		 *****/

		fn = (double) (InterpolateTable(speaker.getAnfnTable(),
				(int) hlsyn.MAXANFN, an) * (speaker.getFno() / speaker
				.getAnfnTable_fno()));

		fm = Compute_fm(frame, speaker);

		/*****
		 * We must use the constriction modified f1 (f1c) to compute any nasal
		 * interactions.
		 *****/

		LOverA = InterpolateTable(speaker.getF1LOverATable(),
				(int) hlsyn.MAXF1LOVERA, state.f1c);

		MmOverMn = (double) (LOverA * an / (3.7 * an + 100.));

		pFNZ = fn
				* (double) Math.sqrt((1. + MmOverMn)
						/ (1. + MmOverMn * fn * fn / (fm * fm)));

		/*****
		 * Compute the bandwidth of the nasal zero. From nasals.c, by Dave
		 * Williams Should this be f1c or f1x or f1? Dave was using f1c times
		 * the alveolar scale (M/F) factor. Ken and Corine thought that this was
		 * correct.
		 *****/

		if (state.f1c < speaker.getBNZ_f1BreakPoint())
			pBNZ = (double) speaker.getNasalBandwidth();
		else
			pBNZ = (double) (speaker.getNasalBandwidth() + 100.0f * MmOverMn);

		llframe.FNZ = ((int) (pFNZ + 0.5f));
		llframe.BNZ = ((int) (pBNZ + 0.5f));
	}

	static double Compute_fm(HLFrame frame, HLSpeaker speaker) {
		double fm, r;

		/*****
		 * Must use f1 here because these effects are irrespective of the
		 * closure acx.
		 *****/

		if (frame.f1 >= speaker.getFm_f1BreakPoint())
			fm = (double) (0.8 * frame.f2 + 0.2 * frame.f3);

		else {
			r = (double) (1.0 + 0.0143 * (frame.f1 - speaker
					.getFm_f1BreakPoint()));
			fm = (double) (r * (0.8 * frame.f2 + 0.2 * frame.f3) + (1. - r) * 3000.);
		}

		return fm;

	}

	static double InterpolateTable(TableRow TheTable[], int TableLength,
			double Column1Point)

	{
		double Column2Point = 0;
		int i;
		int column2Set = hlsyn.NO;

		/*****
		 * It is assumed that Column1 is always increasing in its values.
		 *****/

		/*****
		 * If any value is off the table then its values are set to be either
		 * the minimum of maximum on the table.
		 *****/

		if (TheTable[0].Column1 >= Column1Point) {
			column2Set = hlsyn.YES;
			Column2Point = TheTable[0].Column2;
		}

		else if (TheTable[TableLength - 1].Column1 <= Column1Point) {
			column2Set = hlsyn.YES;
			Column2Point = TheTable[TableLength - 1].Column2;
		}

		else
			for (i = 0; i < TableLength - 1; ++i)
				if (Column1Point >= TheTable[i].Column1
						&& Column1Point < TheTable[i + 1].Column1) {
					Column2Point = LinearInterpolate(Column1Point,
							TheTable[i].Column1, TheTable[i].Column2,
							TheTable[i + 1].Column1, TheTable[i + 1].Column2);
					column2Set = hlsyn.YES;
					break;
				}

		return Column2Point;
	}

	static void NasalFirstFormant(HLFrame frame, HLSpeaker speaker,
			HLState state)

	{
		double pf1x = state.f1x;
		double pb1x = state.b1x;

		double Qf1c, Qfno, a, b, c, temp, an = hlsyn.MAX(0.0f,frame.an);

		/*****
		 * First, compute the bandwidth of the first formant b1x This was
		 * adapted from nasals.c in the Dave Williams version of the code.
		 *****/

		temp = (double) (speaker.getB1m() + hlsyn.MMSQ_TO_CMSQ(an)
				* speaker.getNasalBandwidth());

		if (state.f1c <= speaker.getFno())
			pb1x = temp;

		else {
			if (an <= speaker.getBNP_B1_anLow())
				pb1x = (double) speaker.getNasalBandwidth();

			else if (an >= speaker.getBNP_B1_anHigh())
				pb1x = temp;

			else
				pb1x = LinearInterpolate(an, speaker.getBNP_B1_anLow(),
						speaker.getNasalBandwidth(),
						speaker.getBNP_B1_anHigh(), temp);
		}

		/*****
		 * For the case of f1x which is arbitrarily the smaller solution to the
		 * sum of the susceptances B's, it is acceptable to approximate the Bn
		 * and the (Bp + Bm) as straight lines. The slopes are determined from
		 * the tables.
		 *****/

		c = InterpolateTable(speaker.getF1cTable(), (int) hlsyn.MAXF1C,
				state.f1c);

		if (state.f1c >= speaker.getFno()) {
			a = InterpolateTable(speaker.getAnaTable(), (int) hlsyn.MAXANA, an);
			if (an < speaker.getAnaTable()[0].Column1) { /*
														 * interpolate from the
														 * first tabulated value
														 * of a to a = +infinity
														 * at an = 0, using a
														 * hyperbola a =
														 * const/an
														 */
				Qf1c = an * c;
				Qfno = speaker.getAnaTable()[0].Column1 * a;
			} else {
				Qf1c = c;
				Qfno = a;
			}
		} else {
			b = InterpolateTable(speaker.getAnbTable(), hlsyn.MAXANB, an);
			if (an < speaker.getAnbTable()[0].Column1) { /*
														 * linearly interpolate
														 * from the first
														 * tabulated value of b
														 * to b = 0 at an = 0
														 */
				Qf1c = speaker.getAnbTable()[0].Column1 * c;
				Qfno = an * b;
			} else {
				Qf1c = c;
				Qfno = b;
			}
		}

		if (Math.abs(Qf1c + Qfno) < hlsyn.FLOAT_EPS) {
			pf1x = (double) ((state.f1c + speaker.getFno()) / 2.0f); /*
																		 * a
																		 * guess
																		 */
		} else
			pf1x = (double) ((Qf1c * state.f1c + Qfno * speaker.getFno()) / (Qf1c + Qfno));

		state.f1x = ((float)pf1x);
		state.b1x = ((float)pb1x);

	}

	static void NasalPole(HLFrame frame, HLSpeaker speaker, HLState state,
			LLFrame llframe) {

		double pFNP = llframe.FNP;
		double pBNP = llframe.BNP;

		FNPVars FNPvars = new FNPVars();
		
		double temp, an = (double) hlsyn.MAX(0.0f, frame.an);

		ObjTemp1 o = new ObjTemp1();

		/*****
		 * First, compute the bandwidth of the nasal pole This was adapted from
		 * nasals.c in the Dave Williams version of the code.
		 *****/

		temp = (double) (speaker.getB1m() + hlsyn.MMSQ_TO_CMSQ(an)
				* speaker.getNasalBandwidth());

		if (state.f1c <= speaker.getFno()) {

			if (an <= speaker.getBNP_B1_anLow())
				pBNP = (double) speaker.getNasalBandwidth();

			else if (an >= speaker.getBNP_B1_anHigh())
				pBNP = temp;

			else
				pBNP = LinearInterpolate(an, speaker.getBNP_B1_anLow(),
						speaker.getNasalBandwidth(),
						speaker.getBNP_B1_anHigh(), temp);
		} else
			pBNP = temp;

		/*****
		 * Compute the frequency of the nasal pole.
		 *****/

		FNPvars.setFn(((double) (InterpolateTable(speaker.getAnfnTable(),
				(int) hlsyn.MAXANFN, an) * (speaker.getFno() / speaker
				.getAnfnTable_fno()))));

		if (frame.f2 >= speaker.getFp_f2BreakPoint())
			FNPvars.setFp(((double) (0.00036f * state.f1c
					* (frame.f2 - speaker.getFp_f2BreakPoint()) + (speaker
					.getFp_f2BreakPoint() - 100.f))));
		else
			FNPvars.setFp(((double) (frame.f2 - 100.f)));

		if (FNPvars.getFp() <= FNPvars.getFn())
			pFNP = 0.5f * (FNPvars.getFp() + FNPvars.getFn());
		else {
			/*****
			 * Must search for an FNP which sets the susceptances Bm + Bp + Bn =
			 * 0
			 *****/

			FNPvars.setK1(((speaker.getPharangealArea() / (hlsyn.RHO * hlsyn.SPEEDSOUND))));
			FNPvars.setK2((InterpolateTable(speaker.getAnK2Table(),
					(int) hlsyn.MAXANK2, an)));
			FNPvars.setF1c(state.f1c);

			if (SusceptanceSum(((1.0f + 2.5f * FLT_EPSILON) * FNPvars.getFn()),
					FNPvars) >= 0.0f)
				/*
				 * K2 is (essentially) zero; the Bn hyperbola degenerates to an
				 * L
				 */
				pFNP = (double) hlsyn.MAX(state.f1c, FNPvars.getFn());

			else if (FiniteBracketFNP(FNPvars, state.f1c, o) == FINITE_BRACKETED)
				pFNP = (double) brent.Brent(FNPvars, o.Brac_low, o.Brac_high,
						(double) FNP_TOL, ITMAX, (double) EPS);
			else {
				pFNP = 0.5f * (FNPvars.getFp() + FNPvars.getFn()); /* rough guess */
			}
		}

		llframe.FNP = ((int) (pFNP + 0.5f));
		llframe.BNP = ((int) (pBNP + 0.5f));
	}

	static double SusceptanceSum(double FNPGuess, FNPVars FNPvars) {
		double Bn, BpPlusBm;

		Bn = -FNPvars.getK2() / (FNPGuess - FNPvars.getFn());

		BpPlusBm = (double) (FNPvars.getK1() * Math.tan(hlsyn.PI / 2.
				* (FNPGuess - FNPvars.getF1c()) / (FNPvars.getFp() - FNPvars.getF1c())));

		return Bn + BpPlusBm;
	}

	// X
	static int FiniteBracketFNP(FNPVars FNPvars, double f1c, ObjTemp1 o)

	/*****
	 * This routine brackets the root of the susceptance function
	 * (SusceptanceSum). This root is the Nasal Pole. The routine uses fp and fn
	 * (fn<fp). The susceptance function is assumed to evaluate to +infinity as
	 * one aproaches fp from fn. The susceptance function is assumed to be
	 * -infinity as one approaches fn from fp. It is assumed that the
	 * susceptance function is monotone increasing fn and fp, and that the root
	 * is greater than or equal to f1c. This routine returns a number
	 * (*Brac_low) between the root and fn which evaluates to a finite negative
	 * number and and another number (*Brac_high) between the root and fp which
	 * evaluates to a positive number. The routine also returns FINITE_BRACKETED
	 * if it was successful and NOT_FINITE_BRACKETED if not.
	 *****/

	{
		double min_f, max_f;
		int i;

		/*
		 * Root is known to lie above fn and f1c, and below fp, and one must
		 * avoid the singularities at fn and fp.
		 */

		if (FNPvars.getFn() >= f1c) {
			o.Brac_low = (double) (FNPvars.getFn() + FINITE_OFFSET
					* (FNPvars.getFp() - FNPvars.getFn()));
			min_f = FNPvars.getFn();
		} else
			min_f = o.Brac_low = f1c;

		o.Brac_high = (double) (FNPvars.getFn() + (1.0 - FINITE_OFFSET)
				* (FNPvars.getFp() - FNPvars.getFn()));

		max_f = FNPvars.getFp();

		/* Decrease lower endpoint 'till the function is negative there. */

		for (i = 0; i < MAX_FINITE_ITERATIONS; i++)
			if (SusceptanceSum(o.Brac_low, FNPvars) <= 0.0)
				break;
			else
				o.Brac_low -= (double) ((1.0 - FINITE_OFFSET) * (o.Brac_low - min_f));

		if (i == MAX_FINITE_ITERATIONS)
			return (int) NOT_FINITE_BRACKETED;

		/* Increase upper endpoint 'till the function is positive there. */

		for (i = 0; i < MAX_FINITE_ITERATIONS; i++)
			if (SusceptanceSum(o.Brac_high, FNPvars) >= 0.0)
				break;
			else
				o.Brac_high += (double) ((1.0 - FINITE_OFFSET) * (max_f - o.Brac_high));

		if (i == MAX_FINITE_ITERATIONS)
			return (int) NOT_FINITE_BRACKETED;

		return (int) FINITE_BRACKETED;
	}

	static double LinearInterpolate(double x, double bNP_B1_anLow,
			double nasalBandwidth, double bNP_B1_anHigh, double y2) {
		double Slope, yIntercept;

		Slope = (double) ((y2 - nasalBandwidth) / (bNP_B1_anHigh - bNP_B1_anLow));
		yIntercept = (double) (nasalBandwidth - Slope * bNP_B1_anLow);

		return (Slope * x + yIntercept);
	}

}
