
package com.laps.jhlsyn;

public class flavor {
	/*
	 * HL syn Version 2.2
	 * 
	 * Copyright (c) 1996 - 1997 by Sensimetrics Corporation. All rights
	 * reserved.
	 */

	/*
	 * flavor.h - control conditional compilation of LLsyn, HLsyn32
	 * 
	 * Modification history:
	 * 
	 * 27 Aug 1996 reb: Created. 30 Apr 1997 reb: Removed subflavor no acxf1c
	 * from flavor VHLsyn; added HLSYNAPI.
	 */

	public static final boolean FLAV_NO_ACXF1C = false;

	

	/*
	 * Master "flavors" - select at most one (by leaving the corresponding
	 * preprocessor variable defined).
	 */
	
	
	public final static boolean FLAV_AGHIKLSOURCECUTTOFF_ON = true; //Set (finite) value for speaker->agHiKLSourceCutoff.
									 

}
