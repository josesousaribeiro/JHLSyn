package com.laps.jhlsyn;

public class synth {
	/*****************************************************************************/
	/** SenSyn - Version 2.2 **/
	/**                                                                         **/
	/** Copyright (c) 1991-1996 by Sensimetrics Corporation **/
	/** All rights reserved. **/
	/**                                                                         **/
	/*****************************************************************************/

	/*
	 * synth.h - synthesizer support
	 * 
	 * coded by Eric P. Carlson
	 * 
	 * Modification History: 08 Aug 1996 reb: made floating-point constants
	 * single-precision; do arithmetic in call to pow in dB2amp in precision
	 * determined by Float (not auto- matically in double-precision); archived
	 * as version 2.2. 29 Aug 1993 version 2.0 (library version) 23 Feb 1993
	 * changed INT16 to int, same as unix, v1.1
	 */


	public static double dB2amp(double x) {
		return (double) Math.pow(10.0f, (double) (x) / 20.0f);
	}

	public static int round(double x) {
		return (int) ((x) + 0.5f);
	}

	short INT16;

	final static double TWO_PI = 6.2831852f;

	/* amplitude adjustment constants */
	static final double A_AV = -20.5f;
	static final double A_AH = -64.3f;
	static final double A_AF = -43.7f;
	static final double A_AP = -28;
	static final double A_A1 = -58;
	static final double A_A2F = -70;
	static final double A_A3F = -77;
	static final double A_A4F = -82.6f;
	static final double A_A5F = -86.7f;
	static final double A_A6F = -87.7f;
	static final double A_AB = -73.5f;
	static final double A_ANV = -68.7f;
	static final double A_A1V = -69.1f;
	static final double A_A2V = -77.5f;
	static final double A_A3V = -84.9f;
	static final double A_A4V = -88.5f;
	static final double A_ATV = -81.5f;

	/* speaker definition array offsets */
	final int S_DU = 0;
	final double S_UI = 1;
	final int S_SR = 2;
	final int S_NF = 3;
	final int S_SS = 4;
	final int S_RS = 5;
	final int S_SB = 6;
	final int S_CP = 7;
	final int S_OS = 8;
	final int S_GV = 9;
	final int S_GH = 10;
	final int S_GF = 11;

	/* parameter array offsets */
	final int P_F0 = 0;
	final int P_AV = 1;
	final int P_OQ = 2;
	final int P_SQ = 3;
	final int P_TL = 4;
	final int P_FL = 5;
	final int P_DI = 6;
	final int P_AH = 7;
	final int P_AF = 8;
	final int P_F1 = 9;
	final int P_B1 = 10;
	final int P_DF1 = 11;
	final int P_DB1 = 12;
	final int P_F2 = 13;
	final int P_B2 = 14;
	final int P_F3 = 15;
	final int P_B3 = 16;
	final int P_F4 = 17;
	final int P_B4 = 18;
	final int P_F5 = 19;
	final int P_B5 = 20;
	final int P_F6 = 21;
	final int P_B6 = 22;
	final int P_FNP = 23;
	final int P_BNP = 24;
	final int P_FNZ = 25;
	final int P_BNZ = 26;
	final int P_FTP = 27;
	final int P_BTP = 28;
	final int P_FTZ = 29;
	final int P_BTZ = 30;
	final int P_A2F = 31;
	final int P_A3F = 32;
	final int P_A4F = 33;
	final int P_A5F = 34;
	final int P_A6F = 35;
	final int P_AB = 36;
	final int P_B2F = 37;
	final int P_B3F = 38;
	final int P_B4F = 39;
	final int P_B5F = 40;
	final int P_B6F = 41;
	final int P_ANV = 42;
	final int P_A1V = 43;
	final int P_A2V = 44;
	final int P_A3V = 45;
	final int P_A4V = 46;
	final int P_ATV = 47;
	final int P_F0NEXT = 48;

	/* output array offsets */
	public static final int NUM_OUTPUTS = 21;
	static final int O_NORMAL = 0;
	static final int O_VOICING = 1;
	static final int O_ASPIRATION = 2;
	static final int O_FRICATION = 3;
	static final int O_GLOTTAL = 4;
	static final int O_TRACHEAL_CASC = 5;
	static final int O_NASAL_ZERO_CASC = 6;
	static final int O_NASAL_POLE_CASC = 7;
	static final int O_FORMANT_5_CASC = 8;
	static final int O_FORMANT_4_CASC = 9;
	static final int O_FORMANT_3_CASC = 10;
	static final int O_FORMANT_2_CASC = 11;
	static final int O_FORMANT_1_CASC = 12;
	static final int O_FORMANT_6_PARA = 13;
	static final int O_FORMANT_5_PARA = 14;
	static final int O_FORMANT_4_PARA = 15;
	static final int O_FORMANT_3_PARA = 16;
	static final int O_FORMANT_2_PARA = 17;
	static final int O_FORMANT_1_PARA = 18;
	static final int O_NASAL_PARA = 19;
	static final int O_BYPASS_PARA = 20;

	

	

}
