package com.laps.jhlsyn;

import java.io.DataOutputStream;
import java.io.Serializable;

import com.laps.jhlsyn.pogo.HLFrame;
import com.laps.jhlsyn.pogo.HLState;
import com.laps.jhlsyn.pogo.LLFrame;
import com.laps.jhlsyn.pogo.LLSynth;
import com.laps.jhlsyn.pogo.TSpeakerDef;

public class JHLSyn_for_frame implements Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	int[] raw_frame;
	short[] wave_frame;

	public final int IN_AG = 0;
	public final int IN_AL = 1;
	public final int IN_AB = 2;
	public final int IN_AN = 3;
	public final int IN_UE = 4;
	public final int IN_F0 = 5;
	public final int IN_F1 = 6;
	public final int IN_F2 = 7;
	public final int IN_F3 = 8;
	public final int IN_F4 = 9;
	public final int IN_PS = 10;
	public final int IN_DC = 11;
	public final int IN_AP = 12;

	int samplePerFrame;
	int sampleRate;

	String fileOutputPath = "";

	HLState state, oldstate;
	HLFrame inframe, oldframe;
	LLFrame llframe;
	LLSynth llsynth;
	TSpeakerDef speakerDef;

	DataOutputStream dosOutputFile;

	public JHLSyn_for_frame(int i, int j) {
		
		this.state = new HLState();
		this.oldstate = new HLState();
		this.oldframe = new HLFrame();
		this.speakerDef = new TSpeakerDef();
		this.llsynth = new LLSynth();
		this.inframe = new HLFrame();
		this.llframe = new LLFrame();
		
		
		samplePerFrame = i;
		sampleRate = j;
		fileOutputPath = null;

		inithl.InitializeHLSynthesizer(oldframe, speakerDef.speaker, oldstate,
				1);

		speakerDef.llspeaker.DU = (500); /* duration of utterance (ignored) */
		speakerDef.llspeaker.UI = (samplePerFrame); /*
													 * update interval (samples
													 * per frame)
													 */
		speakerDef.llspeaker.SR = ((int) sampleRate); /* sample rate */
		speakerDef.llspeaker.NF = (5); /* number of formants in cascade */
		speakerDef.llspeaker.SS = (2); /* source select */
		speakerDef.llspeaker.RS = (8); /* random seed */
		speakerDef.llspeaker.SB = (1); /* same burst */
		speakerDef.llspeaker.CP = (0); /* cascade/parallel */
		speakerDef.llspeaker.OS = (0); /* output select */
		speakerDef.llspeaker.GV = (60); /* gain of voicing source */
		speakerDef.llspeaker.GH = (60); /* gain of aspiration noise source */
		speakerDef.llspeaker.GF = (60); /* gain of frication noise source */

//		try {
//			llsynth.spkr = (Speaker) speakerDef.llspeaker.clone();
//			llinit.LLInit(llsynth, speakerDef.llspeaker);
//		} catch (CloneNotSupportedException e) {
//			e.printStackTrace();
//		}

		llsynth.spkr = speakerDef.llspeaker;
		llinit.LLInit(llsynth, speakerDef.llspeaker);
	}

	public short[] runByFrame(int indFrame[]) {

		wave_frame = new short[samplePerFrame];

		int inbuffer[] = new int[14];

		inbuffer[IN_AG] = indFrame[IN_AG];
		inbuffer[IN_AL] = indFrame[IN_AL];
		inbuffer[IN_AB] = indFrame[IN_AB];
		inbuffer[IN_AN] = indFrame[IN_AN];
		inbuffer[IN_UE] = indFrame[IN_UE];
		inbuffer[IN_F0] = indFrame[IN_F0];
		inbuffer[IN_F1] = indFrame[IN_F1];
		inbuffer[IN_F2] = indFrame[IN_F2];
		inbuffer[IN_F3] = indFrame[IN_F3];
		inbuffer[IN_F4] = indFrame[IN_F4];
		inbuffer[IN_PS] = indFrame[IN_PS];
		inbuffer[IN_DC] = indFrame[IN_DC];
		inbuffer[IN_AP] = indFrame[IN_AP];

		inframe.ag = (((float) (inbuffer[IN_AG]) * .01f));
		inframe.al = (((float) (inbuffer[IN_AL]) * .1f));
		inframe.ab = (((float) (inbuffer[IN_AB]) * .1f));
		inframe.ap = (((float) (inbuffer[IN_AP]) * .01f));
		inframe.an = (((float) (inbuffer[IN_AN]) * .1f));
		inframe.ue = ((((float) inbuffer[IN_UE])));

		inframe.ps = (((float) (inbuffer[IN_PS]) * .01f));
		inframe.dc = (((float) (int) inbuffer[IN_DC]));
		inframe.f0 = (inbuffer[IN_F0]);
		inframe.f1 = (inbuffer[IN_F1]); // 500.0f;
		inframe.f2 = (inbuffer[IN_F2]); // 1500.0f;
		inframe.f3 = (inbuffer[IN_F3]); // 2500.0f;
		inframe.f4 = (inbuffer[IN_F4]);

		hlframe.HLSynthesizeLLFrame(inframe, oldframe, speakerDef.speaker,
				state, oldstate, llframe);
		
		
		try {
			oldstate = (HLState) state.clone();
			oldframe = (HLFrame) inframe.clone();
		} catch (CloneNotSupportedException e) {	
			e.printStackTrace();
		}
		

		frame.LLSynthesize(llsynth, llframe, wave_frame);
		return wave_frame;
	}


	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	
	
	public JHLSyn_for_frame cloneManual() throws CloneNotSupportedException{
		JHLSyn_for_frame c = (JHLSyn_for_frame) clone();
		
		c.inframe = (HLFrame) inframe.clone();
		c.llframe = (LLFrame) llframe.clone();
		c.llsynth = (LLSynth) llsynth.cloneManual();
		c.oldframe = (HLFrame) oldframe.clone();
		c.oldstate = (HLState) oldstate.clone();
		c.speakerDef = speakerDef.cloneManual();
		c.state = (HLState) state.clone();
		return c;
	}
	
	

}
