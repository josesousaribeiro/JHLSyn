package com.laps.jhlsyn;

import com.laps.jhlsyn.pogo.Coefficients;
import com.laps.jhlsyn.pogo.Speaker;
import com.laps.jhlsyn.pogo.Synthesizer;

public class llsyn {
	/*****************************************************************************/
	/** SenSyn - Version 2.2 **/
	/**                                                                         **/
	/** Copyright (c) 1991-1997 by Sensimetrics Corporation **/
	/** All rights reserved. **/
	/**                                                                         **/
	/*****************************************************************************/

	/*
	 * llsyn.h - SenSyn top-level declarations
	 * 
	 * coded by Eric P. Carlson
	 * 
	 * Modification History:
	 * 
	 * 30 Apr 1997 reb: used HLSYNAPI rather than FLAV_STDCALL. 27 Aug 1996 reb:
	 * include flavor.h, check FLAV_STDCALL in decl of LLSynthesize, LLInit. 08
	 * Aug 1996 reb: archived as version 2.2 (no changes). 27 Mar 1995 Win32
	 * MSVC version 29 Aug 1993 added Speaker 26 Aug 1993 original
	 */

	int LLSYN_H;

	

	static class LLSynth {
		Synthesizer state;
		Coefficients coefs;
		Speaker spkr;
		Resonator glottal_pulse, spectral_tilt, nasal_pole_cascade,
				formant_1_cascade, formant_2_cascade, formant_3_cascade,
				formant_4_cascade, formant_5_cascade, formant_6_cascade,
				formant_7_cascade, formant_8_cascade, formant_2_parallel,
				formant_3_parallel, formant_4_parallel, formant_5_parallel,
				formant_6_parallel, trach_pole_cascade, formant_1_special,
				formant_2_special, formant_3_special, formant_4_special,
				nasal_pole_special, trach_pole_special;
		Resonator nasal_zero_cascade, trach_zero_cascade; /* anti-resonators */
		double out[];

		public LLSynth() {

			state = new Synthesizer();
			coefs = new Coefficients();
			spkr = new Speaker();
			glottal_pulse = new Resonator();
			spectral_tilt = new Resonator();
			nasal_pole_cascade = new Resonator();
			formant_1_cascade = new Resonator();
			formant_2_cascade = new Resonator();
			formant_3_cascade = new Resonator();
			formant_4_cascade = new Resonator();
			formant_5_cascade = new Resonator();
			formant_6_cascade = new Resonator();
			formant_7_cascade = new Resonator();
			formant_8_cascade = new Resonator();
			formant_2_parallel = new Resonator();
			formant_3_parallel = new Resonator();
			formant_4_parallel = new Resonator();
			formant_5_parallel = new Resonator();
			formant_6_parallel = new Resonator();
			trach_pole_cascade = new Resonator();
			formant_1_special = new Resonator();
			formant_2_special = new Resonator();
			formant_3_special = new Resonator();
			formant_4_special = new Resonator();
			nasal_pole_special = new Resonator();
			trach_pole_special = new Resonator();
			nasal_zero_cascade = new Resonator();
			trach_zero_cascade = new Resonator();

			out = new double[synth.NUM_OUTPUTS];
		}
	}

	static class LLFrame {
		int F0;
		int AV;
		int OQ;
		int SQ;
		int TL;
		int FL;
		int DI;
		int AH;
		int AF;

		int F1;
		int B1;
		int DF1;
		int DB1;
		int F2;
		int B2;
		int F3;
		int B3;
		int F4;
		int B4;
		int F5;
		int B5;
		int F6;
		int B6;

		int FNP;
		int BNP;
		int FNZ;
		int BNZ;
		int FTP;
		int BTP;
		int FTZ;
		int BTZ;

		int A2F;
		int A3F;
		int A4F;
		int A5F;
		int A6F;
		int AB;
		int B2F;
		int B3F;
		int B4F;
		int B5F;
		int B6F;

		int ANV;
		int A1V;
		int A2V;
		int A3V;
		int A4V;
		int ATV;
	}

	int WIN32;

}
