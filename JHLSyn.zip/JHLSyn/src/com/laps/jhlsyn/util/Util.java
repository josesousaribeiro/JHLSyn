package com.laps.jhlsyn.util;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Util {

	private static String header_hlsyn = "AG";

	public static int[][] readHLSynFile(String file) throws IOException {
		BufferedReader br = null;
		ArrayList<String> sb = null;

		try {
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			System.err.println("Não foi possível encontrar o arquivo");
			e.printStackTrace();
		}
		try {
			sb = new ArrayList<String>();
			String line = "";

			while ((line = br.readLine()) != null) {
				if (!line.contains(header_hlsyn)) {
					sb.add(line);
				}
			}

		} finally {
			br.close();
		}

		int [][]mat_out = arrayListStrinToMatInt(sb);
		

		return mat_out;
	}
	
	public static int[][] arrayListStrinToMatInt(ArrayList<String> sb){
		int lines = sb.size();
		int[][] mat_out = new int[lines][13];
		for (int i = 0; i < lines; i++) {
			mat_out[i] = stringFrameToIntArrayFrame(sb.get(i));
		}
		
		return mat_out;
	}

	public static int[] stringFrameToIntArrayFrame(String frame) {
		String[] t1 = frame.split(" ");
		int[] t2 = new int[t1.length];
		for (int i = 0; i < t2.length; i++) {
			t2[i] = Integer.parseInt(t1[i]);
		}
		return t2;
	}
	
	public static void deletFile(String file){
		File temp = new File(file);
		if(temp.exists()){
			temp.delete();
		}
	}
	
	public static Object deepClone(Object object) {
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(baos);
			oos.writeObject(object);
			ByteArrayInputStream bais = new ByteArrayInputStream(
					baos.toByteArray());
			ObjectInputStream ois = new ObjectInputStream(bais);
			return ois.readObject();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
