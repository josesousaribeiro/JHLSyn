package com.laps.jhlsyn;

import com.laps.jhlsyn.pogo.LLFrame;
import com.laps.jhlsyn.pogo.LLSynth;

public class voice {
	/*****************************************************************************/
	/** SenSyn - Version 2.2 **/
	/**                                                                         **/
	/** Copyright (c) 1991-1996 by Sensimetrics Corporation **/
	/** All rights reserved. **/
	/**                                                                         **/
	/*****************************************************************************/

	/*
	 * voice.c - synthesize one voice sample
	 * 
	 * coded by Eric P. Carlson
	 * 
	 * Modification History:
	 * 
	 * 27 Aug 1996 reb: include flavor.h 08 Aug 1996 reb: made floating-point
	 * constants single-precision; archived as version 2.2. 29 Aug 1993 version
	 * 2.0 (library version) 23 Feb 1993 made lf tables same as unix version,
	 * v1.1 10 Mar 1992 return spectral_tilt(0) when F0 = 0 21 Nov 1991 made
	 * spectral_tilt, formant_1s pitch-synchronous 7 Nov 1991 removed from
	 * sample.c
	 */
	/* Spectral Tilt Bandwidth table */
	final static int tilt[] = { 5000, 4350, 3790, 3330, 2930, 2700, 2580, 2468, 2364,
			2260, 2157, 2045, 1925, 1806, 1687, 1568, 1449, 1350, 1272, 1199,
			1133, 1071, 1009, 947, 885, 833, 781, 729, 677, 625, 599, 573, 547,
			521, 495, 469, 442, 416, 390, 364, 338, 312 };

	/* LF Voicing Model tables */
	final static double bw_lf[] = { 0.0f, -0.6f, -2.0f, -4.0f, -6.0f, -8.0f, -10.4f,
			-12.7f, -15.3f, -17.8f, -20.1f, -22.4f, -24.7f, -27.0f, -29.2f,
			-31.4f, -33.6f, -35.8f, -37.9f, -40.0f, -42.1f, -44.1f, -46.2f,
			-48.3f, -50.4f, -52.4f, -54.5f, -56.6f, -57.8f, -60.8f, -62.7f,
			-64.5f, -66.3f, -68.1f, -69.9f, -71.6f, -73.3f, -75.0f, -76.6f,
			-78.2f, -79.6f };

	final static double e0_lf[] = { 27.4f, 26.3f, 25.3f, 24.3f, 23.2f, 22.1f, 21.0f,
			20.0f, 18.8f, 17.6f, 16.1f, 14.9f, 13.8f, 12.8f, 11.7f, 10.6f,
			9.81f, 9.00f, 8.12f, 7.36f, 6.60f, 6.05f, 5.46f, 4.92f, 4.41f,
			3.94f, 3.58f, 3.14f, 2.83f, 2.49f, 2.24f, 2.03f, 1.83f, 1.63f,
			1.48f, 1.32f, 1.19f, 1.08f, .982f, .902f, .832f };

	/* ---------------------------------------------------------------------- */

	static double next_voice_sample(LLSynth mSynth, LLFrame frame) {
		double output = 0.0f;
		double freq, bw, temp, time, open, seconds;
		int pulse;

		mSynth.state.global_time++; /* flutter time runs continuously */

		/* check for F0 = zero */
		if (frame.F0 == 0) {
			mSynth.state.period_ctr = 0; /*
										 * make sure we open glottis when F0 !=
										 * 0
										 */
			mSynth.state.glottis_open = 0;
			mSynth.state.voicing_state = 0;
			return reson.AdvanceResonator(mSynth.spectral_tilt, 0.f);
		}

		/* glottal opening/closing transition */
		if ((--mSynth.state.period_ctr) <= 0) { /* check for glottal transition */
			if (mSynth.state.glottis_open == 0) { /* glottis opening */
				mSynth.state.glottis_open = 1;
				mSynth.state.pulse = 1;
				mSynth.state.voicing_time = 0;
				mSynth.state.F0 = frame.F0;
				mSynth.state.FL = frame.FL;
				mSynth.state.OQ = frame.OQ;
				mSynth.state.SQ = frame.SQ;
				mSynth.state.DI = frame.DI;
				mSynth.state.AV = frame.AV;
				mSynth.state.TL = frame.TL;
				mSynth.state.voicing_amp = mSynth.state.AV != 0 ? synth
						.dB2amp(mSynth.spkr.GV + mSynth.state.AV + synth.A_AV)
						: 0;
				if (mSynth.state.FL != 0) {
					seconds = (float) mSynth.state.global_time / mSynth.spkr.SR;
					freq = mSynth.state.F0
							/ 10.f
							+ (mSynth.state.FL / 50.f * mSynth.state.F0 / 600.f * (double) (Math
									.cos(synth.TWO_PI * 12.7f * seconds)
									+ Math.cos(synth.TWO_PI * 7.1f * seconds) + Math
										.cos(synth.TWO_PI * 4.7f * seconds)));
				} else
					freq = mSynth.state.F0 / 10.f;
				mSynth.state.pulse_freq = (int) Math.round(mSynth.spkr.SR
						/ freq);
				mSynth.state.period_ctr = (int) Math
						.round(mSynth.state.pulse_freq * mSynth.state.OQ / 100.);
				mSynth.state.close_time = mSynth.state.pulse_freq
						- mSynth.state.period_ctr;
				if (mSynth.state.DI != 0)
					if (mSynth.state.close_shortened == 0) {
						mSynth.state.close_shortened = 1;
						mSynth.state.close_time -= Math
								.round(mSynth.state.close_time
										* mSynth.state.DI / 100.);
						mSynth.state.voicing_amp *= 1.f - mSynth.state.DI / 100.f;
						/*** the following is not quite right ***/
						mSynth.state.TL += Math.round(mSynth.state.DI / 4.25);
					} else { /* previous close shortened */
						mSynth.state.close_shortened = 0;
						mSynth.state.close_time += Math
								.round(mSynth.state.close_time
										* mSynth.state.DI / 100.);
					}
				else
					/* no diplophonia */
					mSynth.state.close_shortened = 0;

				/* setup spectral tilt */
				if (mSynth.spkr.SS == 3) /* LF source corner rounding */
					mSynth.state.TL += 2;

				
				if (mSynth.state.TL >= 0 && mSynth.state.TL < tilt.length) {
					reson.SetPolePair(mSynth.spectral_tilt,
							(int) Math.round(0.375 * tilt[mSynth.state.TL]),
							tilt[mSynth.state.TL], mSynth.spkr.SR);
				} else
					reson.SetPolePair(mSynth.spectral_tilt,
							(int) Math.round(0.375 * tilt[7]),
							tilt[7], mSynth.spkr.SR);
					
				if (mSynth.state.TL > 10)
					mSynth.spectral_tilt.getCoef().A *= 1.0f
							+ (mSynth.state.TL - 10) * (mSynth.state.TL - 10)
							/ 1000.f;

				/*
				 * setup pitch-synchronous formant_1_cascade and
				 * formant_1_special
				 */
				reson.InterPolePair(mSynth.formant_1_cascade, frame.F1
						+ frame.DF1, frame.B1 + frame.DB1, mSynth.spkr.SR);
				reson.InterPolePair(mSynth.formant_1_special, frame.F1
						+ frame.DF1, frame.B1 + frame.DB1, mSynth.spkr.SR);

				switch (mSynth.spkr.SS) {
				case 1: /* impulsive source */
					mSynth.state.voicing_state = 0;
					temp = (double) mSynth.state.pulse_freq * mSynth.state.OQ
							/ 100.f;
					reson.SetPolePair(mSynth.glottal_pulse, 0,
							Math.round(10000. / temp), mSynth.spkr.SR);
					mSynth.glottal_pulse.getCoef().A *= 0.002675f * temp * temp; /*
																				 * -
																				 * 51.3
																				 * dB
																				 */
					break;

				case 2: /* natural source */
					/** nothing to do **/
					break;

				case 3: /* LF source */
					freq = mSynth.state.F0 / (22.f * mSynth.state.OQ / 100.f)
							* (mSynth.state.SQ + 100.f) / mSynth.state.SQ;
					temp = (bw_lf[mSynth.state.SQ / 10 - 9] - bw_lf[mSynth.state.SQ / 10 - 10]) / 10.f;
					bw = (bw_lf[mSynth.state.SQ / 10 - 10] + (mSynth.state.SQ % 10)
							* temp)
							* 200.f
							/ (mSynth.state.pulse_freq * mSynth.state.OQ / 100.f);
					reson.SetPolePair(mSynth.glottal_pulse,
							(int) Math.round(freq), Math.round(bw),
							mSynth.spkr.SR);
					temp = (e0_lf[mSynth.state.SQ / 10 - 9] - e0_lf[mSynth.state.SQ / 10 - 10]) / 10.f;
					mSynth.glottal_pulse.getCoef().A *= (e0_lf[mSynth.state.SQ / 10 - 10] + (mSynth.state.SQ % 10)
							* temp)
							* (mSynth.state.pulse_freq * mSynth.state.OQ / 100.f)
							/ 200.f;
					break;
				}
			} else { /* glottis closing */
				mSynth.state.glottis_open = 0;
				mSynth.state.voicing_time++;
				mSynth.state.pulse = 0;
				mSynth.state.period_ctr = mSynth.state.close_time;
				reson.InterPolePair(mSynth.formant_1_cascade, frame.F1,
						frame.B1, mSynth.spkr.SR);
				reson.InterPolePair(mSynth.formant_1_special, frame.F1,
						frame.B1, mSynth.spkr.SR);
			}
		} else { /* during open or closed phase */
			mSynth.state.voicing_time++;
			mSynth.state.pulse = 0;
		}

		/*
		 * ----------------------------------------------------------------------
		 */
		/* voicing source */

		switch (mSynth.spkr.SS) {
		case 1: /* impulse source */
			pulse = mSynth.state.pulse - mSynth.state.voicing_state;
			mSynth.state.voicing_state = mSynth.state.pulse;
			output = reson.AdvanceResonator(
					mSynth.spectral_tilt,
					reson.AdvanceResonator(mSynth.glottal_pulse, pulse
							* mSynth.state.voicing_amp));
			break;

		case 2: /* natural KLGLOT88 source */
			/*****
			 * The code was crashing before the break for no apparent reason. I
			 * recompiled in DOS then came to Windows and rebuilt again and it
			 * worked????
			 *****/
			if (mSynth.state.glottis_open != 0) {
				time = (double) mSynth.state.voicing_time;
				open = (double) mSynth.state.pulse_freq * mSynth.state.OQ
						/ 100.f;
				temp = mSynth.state.voicing_amp
						* .00055f
						* (mSynth.state.pulse_freq != 0 ? 100.f / mSynth.state.pulse_freq
								: 0) * (50.f / mSynth.state.OQ)
						* (2 * time - 3 * time * time / open);
				output = reson.AdvanceResonator(mSynth.spectral_tilt, temp);
			} else
				output = reson.AdvanceResonator(mSynth.spectral_tilt, 0.f);
			break;

		case 3: /* LF model source */
			if (mSynth.state.glottis_open != 0)
				output = reson
						.AdvanceResonator(
								mSynth.spectral_tilt,
								reson.AdvanceResonator(
										mSynth.glottal_pulse,
										mSynth.state.pulse != 0 ? (mSynth.state.voicing_amp * 0.0795f)
												: 0.f));
			else
				reson.ClearResonator(mSynth.glottal_pulse);
			output = reson.AdvanceResonator(mSynth.spectral_tilt, 0.f);
			break;
		}

		return output;
	}

}
