package com.laps.jhlsyn.pogo;

import java.io.Serializable;

public class HLState implements Cloneable, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public double acl; /* area of liquid contraction, mm^2 */
	public double acd; /* area of dorsum contraction, mm^2 */
	public int loc; /* location of smallest contraction */
	public double acx; /* area of smallest contraction, mm^2 */
	public double agx; /* area of tracheal adjusted glottal contraction, mm^2 */
	public double Pm; /* pressure in the mouth, dynes/cm^2 */
	public double Pcw; /* pressure across the wall capacitance, dynes/cm^2 */
	public double Ug; /* glottal flow, cm^3/s */
	public double Uacx; /* flow across constriction (acx), cm^3/s */
	public double Un; /* flow into the nose, cm^3/s */
	public double Uw; /* flow into the parallel Rw, Cw branch (wall), cm^3/s */
	public double f1c; /* f1 adjusted by constrictions, Hz */
	public double f1x; /* f1 adjusted by constrictions and nose, Hz */
	public double b1x; /* b1 adjusted by nose, Hz */
	public double Cw; /* compliance of the pharyngeal walls (Cwm adjusted by dc) */
	public double Cg; /* compliance of the glottis (Cgm adjusted by dc) */
	public double agf; /* area of the glottis for calculating flow */

	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
}
