package com.laps.jhlsyn.pogo;

import java.io.Serializable;

public class ObjTemp2 implements Serializable, Cloneable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public double MinGuess, MaxGuess;

	
	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
}
