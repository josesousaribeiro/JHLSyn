package com.laps.jhlsyn.pogo;

import java.io.Serializable;

public class PmRootFunctionArgs implements Serializable, Cloneable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	
	public double rootTwoOverRho;
	public double ag;
	public double acx;
	public double an;
	public double ap;
	public double ue;
	public double ps;
	public double Lg;
	public double Cg;
	public double Cw;
	public double A;
	public double B;
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
}
