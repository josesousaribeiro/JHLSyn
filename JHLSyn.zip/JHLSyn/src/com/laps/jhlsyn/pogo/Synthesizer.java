package com.laps.jhlsyn.pogo;

import java.io.Serializable;

/* Synthesizer structure */
public class Synthesizer implements Serializable, Cloneable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/* static data */
	public int parallel_only_flag;
	public int num_casc_formants;
	public int num_samples;
	public int output_select;

	/* dynamic state data */
	public int pulse_freq;
	public int glottis_open;
	public int period_ctr;
	public int voicing_state;
	public int pulse;
	public int random;
	public int voicing_time;
	public long global_time;
	public double voicing_amp;
	public double glottal_state;
	public double asp_state;
	public double integrator;

	/* voicing state */
	public int F0;
	public int FL;
	public int OQ;
	public int SQ;
	public int DI;
	public int AV;
	public int TL;
	public int close_shortened;
	public int close_time;
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
}
