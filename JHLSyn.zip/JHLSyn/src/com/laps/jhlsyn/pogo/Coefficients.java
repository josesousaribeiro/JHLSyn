package com.laps.jhlsyn.pogo;

import java.io.Serializable;

public class Coefficients implements Serializable,Cloneable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public double asp_amp;
	public double fric_amp;
	public double f1p_amp;
	public double f2p_amp;
	public double f3p_amp;
	public double f4p_amp;
	public double f5p_amp;
	public double f6p_amp;
	public double npv_amp;
	public double f1v_amp;
	public double f2v_amp;
	public double f3v_amp;
	public double f4v_amp;
	public double tpv_amp;
	public double bypass_amp;
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
}