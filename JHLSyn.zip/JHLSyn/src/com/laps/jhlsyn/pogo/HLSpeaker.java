package com.laps.jhlsyn.pogo;

import java.io.Serializable;

import com.laps.jhlsyn.hlsyn;

public class HLSpeaker implements Serializable, Cloneable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public double getVal() {
		return Val;
	}
	public void setVal(double val) {
		Val = val;
	}
	public double getLc_al() {
		return Lc_al;
	}
	public void setLc_al(double lc_al) {
		Lc_al = lc_al;
	}
	public double getHelmholtzZeroAreaFrequency() {
		return HelmholtzZeroAreaFrequency;
	}
	public void setHelmholtzZeroAreaFrequency(double helmholtzZeroAreaFrequency) {
		HelmholtzZeroAreaFrequency = helmholtzZeroAreaFrequency;
	}
	public double getVab() {
		return Vab;
	}
	public void setVab(double vab) {
		Vab = vab;
	}
	public double getLc_ab() {
		return Lc_ab;
	}
	public void setLc_ab(double lc_ab) {
		Lc_ab = lc_ab;
	}
	public double getF1Min() {
		return f1Min;
	}
	public void setF1Min(double f1Min) {
		this.f1Min = f1Min;
	}
	public double getF1Max() {
		return f1Max;
	}
	public void setF1Max(double f1Max) {
		this.f1Max = f1Max;
	}
	public double getF2RetroflexMax() {
		return f2RetroflexMax;
	}
	public void setF2RetroflexMax(double f2RetroflexMax) {
		this.f2RetroflexMax = f2RetroflexMax;
	}
	public double getF3RetroflexMax() {
		return f3RetroflexMax;
	}
	public void setF3RetroflexMax(double f3RetroflexMax) {
		this.f3RetroflexMax = f3RetroflexMax;
	}
	public double getF2LateralMax() {
		return f2LateralMax;
	}
	public void setF2LateralMax(double f2LateralMax) {
		this.f2LateralMax = f2LateralMax;
	}
	public double getF3LateralMin() {
		return f3LateralMin;
	}
	public void setF3LateralMin(double f3LateralMin) {
		this.f3LateralMin = f3LateralMin;
	}
	public double getKacl() {
		return Kacl;
	}
	public void setKacl(double kacl) {
		Kacl = kacl;
	}
	public double getAclFreq() {
		return aclFreq;
	}
	public void setAclFreq(double aclFreq) {
		this.aclFreq = aclFreq;
	}
	public double getVacd() {
		return Vacd;
	}
	public void setVacd(double vacd) {
		Vacd = vacd;
	}
	public double getLc_acd() {
		return Lc_acd;
	}
	public void setLc_acd(double lc_acd) {
		Lc_acd = lc_acd;
	}
	public double getAcdMax() {
		return acdMax;
	}
	public void setAcdMax(double acdMax) {
		this.acdMax = acdMax;
	}
	public double getAcd_f1Break() {
		return acd_f1Break;
	}
	public void setAcd_f1Break(double acd_f1Break) {
		this.acd_f1Break = acd_f1Break;
	}
	public double getKHi() {
		return KHi;
	}
	public void setKHi(double kHi) {
		KHi = kHi;
	}
	public double getF1HiShift() {
		return f1HiShift;
	}
	public void setF1HiShift(double f1HiShift) {
		this.f1HiShift = f1HiShift;
	}
	public double getFno() {
		return fno;
	}
	public void setFno(double fno) {
		this.fno = fno;
	}
	public double getAnfnTable_fno() {
		return anfnTable_fno;
	}
	public void setAnfnTable_fno(double anfnTable_fno) {
		this.anfnTable_fno = anfnTable_fno;
	}
	public double getFm_f1BreakPoint() {
		return fm_f1BreakPoint;
	}
	public void setFm_f1BreakPoint(double fm_f1BreakPoint) {
		this.fm_f1BreakPoint = fm_f1BreakPoint;
	}
	public double getBNZ_f1BreakPoint() {
		return BNZ_f1BreakPoint;
	}
	public void setBNZ_f1BreakPoint(double bNZ_f1BreakPoint) {
		BNZ_f1BreakPoint = bNZ_f1BreakPoint;
	}
	public TableRow[] getAnK2Table() {
		return anK2Table;
	}
	public void setAnK2Table(TableRow[] anK2Table) {
		this.anK2Table = anK2Table;
	}
	public TableRow[] getAnaTable() {
		return anaTable;
	}
	public void setAnaTable(TableRow[] anaTable) {
		this.anaTable = anaTable;
	}
	public TableRow[] getAnbTable() {
		return anbTable;
	}
	public void setAnbTable(TableRow[] anbTable) {
		this.anbTable = anbTable;
	}
	public TableRow[] getAnfnTable() {
		return anfnTable;
	}
	public void setAnfnTable(TableRow[] anfnTable) {
		this.anfnTable = anfnTable;
	}
	public TableRow[] getF1LOverATable() {
		return f1LOverATable;
	}
	public void setF1LOverATable(TableRow[] f1lOverATable) {
		f1LOverATable = f1lOverATable;
	}
	public TableRow[] getF1cTable() {
		return f1cTable;
	}
	public void setF1cTable(TableRow[] f1cTable) {
		this.f1cTable = f1cTable;
	}
	public double getNasalBandwidth() {
		return NasalBandwidth;
	}
	public void setNasalBandwidth(double nasalBandwidth) {
		NasalBandwidth = nasalBandwidth;
	}
	public double getBNP_B1_anLow() {
		return BNP_B1_anLow;
	}
	public void setBNP_B1_anLow(double bNP_B1_anLow) {
		BNP_B1_anLow = bNP_B1_anLow;
	}
	public double getBNP_B1_anHigh() {
		return BNP_B1_anHigh;
	}
	public void setBNP_B1_anHigh(double bNP_B1_anHigh) {
		BNP_B1_anHigh = bNP_B1_anHigh;
	}
	public double getFp_f2BreakPoint() {
		return fp_f2BreakPoint;
	}
	public void setFp_f2BreakPoint(double fp_f2BreakPoint) {
		this.fp_f2BreakPoint = fp_f2BreakPoint;
	}
	public double getPharangealArea() {
		return PharangealArea;
	}
	public void setPharangealArea(double pharangealArea) {
		PharangealArea = pharangealArea;
	}
	public double getCwm() {
		return Cwm;
	}
	public void setCwm(double cwm) {
		Cwm = cwm;
	}
	public double getRw() {
		return Rw;
	}
	public void setRw(double rw) {
		Rw = rw;
	}
	public double getPsm() {
		return Psm;
	}
	public void setPsm(double psm) {
		Psm = psm;
	}
	public double getCgm() {
		return Cgm;
	}
	public void setCgm(double cgm) {
		Cgm = cgm;
	}
	public double getLg() {
		return Lg;
	}
	public void setLg(double lg) {
		Lg = lg;
	}
	public double getNewtonInterpTimeStep() {
		return NewtonInterpTimeStep;
	}
	public void setNewtonInterpTimeStep(double newtonInterpTimeStep) {
		NewtonInterpTimeStep = newtonInterpTimeStep;
	}
	public double getUpdateInterval() {
		return UpdateInterval;
	}
	public void setUpdateInterval(double updateInterval) {
		UpdateInterval = updateInterval;
	}
	public double getLabialAB() {
		return LabialAB;
	}
	public void setLabialAB(double labialAB) {
		LabialAB = labialAB;
	}
	public double getPalVelarA2F() {
		return PalVelarA2F;
	}
	public void setPalVelarA2F(double palVelarA2F) {
		PalVelarA2F = palVelarA2F;
	}
	public double getPalVelarA5F() {
		return PalVelarA5F;
	}
	public void setPalVelarA5F(double palVelarA5F) {
		PalVelarA5F = palVelarA5F;
	}
	public double getPalVelarA3F() {
		return PalVelarA3F;
	}
	public void setPalVelarA3F(double palVelarA3F) {
		PalVelarA3F = palVelarA3F;
	}
	public double getPalVelar_f2Offset() {
		return PalVelar_f2Offset;
	}
	public void setPalVelar_f2Offset(double palVelar_f2Offset) {
		PalVelar_f2Offset = palVelar_f2Offset;
	}
	public double getPalVelar_f2Overf3_Slope() {
		return PalVelar_f2Overf3_Slope;
	}
	public void setPalVelar_f2Overf3_Slope(double palVelar_f2Overf3_Slope) {
		PalVelar_f2Overf3_Slope = palVelar_f2Overf3_Slope;
	}
	public double getRetroflexA3F() {
		return RetroflexA3F;
	}
	public void setRetroflexA3F(double retroflexA3F) {
		RetroflexA3F = retroflexA3F;
	}
	public double getLateralA3F() {
		return LateralA3F;
	}
	public void setLateralA3F(double lateralA3F) {
		LateralA3F = lateralA3F;
	}
	public FricativeGains[][] getAlveolar() {
		return alveolar;
	}
	public void setAlveolar(FricativeGains[][] alveolar) {
		this.alveolar = alveolar;
	}
	public double getB2F() {
		return B2F;
	}
	public void setB2F(double b2f) {
		B2F = b2f;
	}
	public double getB3F() {
		return B3F;
	}
	public void setB3F(double b3f) {
		B3F = b3f;
	}
	public double getB4F() {
		return B4F;
	}
	public void setB4F(double b4f) {
		B4F = b4f;
	}
	public double getB5F() {
		return B5F;
	}
	public void setB5F(double b5f) {
		B5F = b5f;
	}
	public double getAgm() {
		return agm;
	}
	public void setAgm(double agm) {
		this.agm = agm;
	}
	public double getAgAVModalOffsetMax() {
		return agAVModalOffsetMax;
	}
	public void setAgAVModalOffsetMax(double agAVModalOffsetMax) {
		this.agAVModalOffsetMax = agAVModalOffsetMax;
	}
	public double getAgAVModalOffsetOnOff() {
		return agAVModalOffsetOnOff;
	}
	public void setAgAVModalOffsetOnOff(double agAVModalOffsetOnOff) {
		this.agAVModalOffsetOnOff = agAVModalOffsetOnOff;
	}
	public double getAgMin() {
		return agMin;
	}
	public void setAgMin(double agMin) {
		this.agMin = agMin;
	}
	public double getAgHiKLSourceCutoff() {
		return agHiKLSourceCutoff;
	}
	public void setAgHiKLSourceCutoff(double agHiKLSourceCutoff) {
		this.agHiKLSourceCutoff = agHiKLSourceCutoff;
	}
	public double getAVPressureThreshold() {
		return AVPressureThreshold;
	}
	public void setAVPressureThreshold(double aVPressureThreshold) {
		AVPressureThreshold = aVPressureThreshold;
	}
	public double getKv() {
		return Kv;
	}
	public void setKv(double kv) {
		Kv = kv;
	}
	public double getKdAV0() {
		return KdAV0;
	}
	public void setKdAV0(double kdAV0) {
		KdAV0 = kdAV0;
	}
	public double getKdAV() {
		return KdAV;
	}
	public void setKdAV(double kdAV) {
		KdAV = kdAV;
	}
	public double getKdAV1() {
		return KdAV1;
	}
	public void setKdAV1(double kdAV1) {
		KdAV1 = kdAV1;
	}
	public double getKa() {
		return Ka;
	}
	public void setKa(double ka) {
		Ka = ka;
	}
	public double getKf() {
		return Kf;
	}
	public void setKf(double kf) {
		Kf = kf;
	}
	public double getAFInterpTimeStep() {
		return AFInterpTimeStep;
	}
	public void setAFInterpTimeStep(double aFInterpTimeStep) {
		AFInterpTimeStep = aFInterpTimeStep;
	}
	public double getAFThreshold() {
		return AFThreshold;
	}
	public void setAFThreshold(double aFThreshold) {
		AFThreshold = aFThreshold;
	}
	public double getOQm() {
		return OQm;
	}
	public void setOQm(double oQm) {
		OQm = oQm;
	}
	public double getKOQ() {
		return KOQ;
	}
	public void setKOQ(double kOQ) {
		KOQ = kOQ;
	}
	public double getOQMax() {
		return OQMax;
	}
	public void setOQMax(double oQMax) {
		OQMax = oQMax;
	}
	public double getOQMin() {
		return OQMin;
	}
	public void setOQMin(double oQMin) {
		OQMin = oQMin;
	}
	public double getTLBreakArea() {
		return TLBreakArea;
	}
	public void setTLBreakArea(double tLBreakArea) {
		TLBreakArea = tLBreakArea;
	}
	public double getKTL() {
		return KTL;
	}
	public void setKTL(double kTL) {
		KTL = kTL;
	}
	public double getTLm() {
		return TLm;
	}
	public void setTLm(double tLm) {
		TLm = tLm;
	}
	public double getSFromf4() {
		return SFromf4;
	}
	public void setSFromf4(double sFromf4) {
		SFromf4 = sFromf4;
	}
	public double getSDefault() {
		return SDefault;
	}
	public void setSDefault(double sDefault) {
		SDefault = sDefault;
	}
	public double getPctSfordBTL() {
		return PctSfordBTL;
	}
	public void setPctSfordBTL(double pctSfordBTL) {
		PctSfordBTL = pctSfordBTL;
	}
	public double getdBTLforPctS() {
		return dBTLforPctS;
	}
	public void setdBTLforPctS(double dBTLforPctS) {
		this.dBTLforPctS = dBTLforPctS;
	}
	public double getTLMax() {
		return TLMax;
	}
	public void setTLMax(double tLMax) {
		TLMax = tLMax;
	}
	public double getTLMin() {
		return TLMin;
	}
	public void setTLMin(double tLMin) {
		TLMin = tLMin;
	}
	public double getAgDIMin() {
		return agDIMin;
	}
	public void setAgDIMin(double agDIMin) {
		this.agDIMin = agDIMin;
	}
	public double getKDI() {
		return KDI;
	}
	public void setKDI(double kDI) {
		KDI = kDI;
	}
	public double getKdF() {
		return KdF;
	}
	public void setKdF(double kdF) {
		KdF = kdF;
	}
	public double getF1T() {
		return F1T;
	}
	public void setF1T(double f1t) {
		F1T = f1t;
	}
	public double getB1m() {
		return B1m;
	}
	public void setB1m(double b1m) {
		B1m = b1m;
	}
	public double getB2m() {
		return B2m;
	}
	public void setB2m(double b2m) {
		B2m = b2m;
	}
	public double getB3m() {
		return B3m;
	}
	public void setB3m(double b3m) {
		B3m = b3m;
	}
	public double getB4m() {
		return B4m;
	}
	public void setB4m(double b4m) {
		B4m = b4m;
	}
	public double getB5m() {
		return B5m;
	}
	public void setB5m(double b5m) {
		B5m = b5m;
	}
	public double getKB3() {
		return KB3;
	}
	public void setKB3(double kB3) {
		KB3 = kB3;
	}
	public double getKB4() {
		return KB4;
	}
	public void setKB4(double kB4) {
		KB4 = kB4;
	}
	public double getKB5() {
		return KB5;
	}
	public void setKB5(double kB5) {
		KB5 = kB5;
	}
	public double getF5() {
		return F5;
	}
	public void setF5(double f5) {
		F5 = f5;
	}
	public double getA6F() {
		return A6F;
	}
	public void setA6F(double a6f) {
		A6F = a6f;
	}
	public double getF6() {
		return F6;
	}
	public void setF6(double f6) {
		F6 = f6;
	}
	public double getB6F() {
		return B6F;
	}
	public void setB6F(double b6f) {
		B6F = b6f;
	}
	public double getKCw() {
		return KCw;
	}
	public void setKCw(double kCw) {
		KCw = kCw;
	}
	public double getKCg() {
		return KCg;
	}
	public void setKCg(double kCg) {
		KCg = kCg;
	}
	public double getKdf0dc() {
		return Kdf0dc;
	}
	public void setKdf0dc(double kdf0dc) {
		Kdf0dc = kdf0dc;
	}
	public double getKpd() {
		return Kpd;
	}
	public void setKpd(double kpd) {
		Kpd = kpd;
	}
	public double getKf1() {
		return Kf1;
	}
	public void setKf1(double kf1) {
		Kf1 = kf1;
	}
	public double getF1_neutral() {
		return f1_neutral;
	}
	public void setF1_neutral(double f1_neutral) {
		this.f1_neutral = f1_neutral;
	}
	public double getKdPTdc() {
		return KdPTdc;
	}
	public void setKdPTdc(double kdPTdc) {
		KdPTdc = kdPTdc;
	}
	public double getF0_vowelshift_f1_break() {
		return f0_vowelshift_f1_break;
	}
	public void setF0_vowelshift_f1_break(double f0_vowelshift_f1_break) {
		this.f0_vowelshift_f1_break = f0_vowelshift_f1_break;
	}
	public double getLt() {
		return Lt;
	}
	public void setLt(double lt) {
		Lt = lt;
	}
	public double getAt() {
		return At;
	}
	public void setAt(double at) {
		At = at;
	}
	public double getLvg() {
		return Lvg;
	}
	public void setLvg(double lvg) {
		Lvg = lvg;
	}
	public double getLv() {
		return Lv;
	}
	public void setLv(double lv) {
		Lv = lv;
	}
	public double getAv() {
		return Av;
	}
	public void setAv(double av) {
		Av = av;
	}
	public double getLhp() {
		return Lhp;
	}
	public void setLhp(double lhp) {
		Lhp = lhp;
	}
	public HLSpeaker() {

		alveolar = new FricativeGains[(int) hlsyn.ALV_F2_POINTS][(int) hlsyn.ALV_F3_POINTS];
		anbTable = new TableRow[hlsyn.MAXANB];
		f1LOverATable = new TableRow[hlsyn.MAXF1LOVERA];
		anaTable = new TableRow[hlsyn.MAXANA];
		f1cTable = new TableRow[hlsyn.MAXF1C];
		anK2Table = new TableRow[hlsyn.MAXANK2];
		anfnTable = new TableRow[hlsyn.MAXANFN];

		for (int i = 0; i < alveolar.length; i++) {
			for (int j = 0; j < alveolar[i].length; j++)
				alveolar[i][j] = new FricativeGains();
		}
		for (int i = 0; i < anbTable.length; i++) {
			anbTable[i] = new TableRow();
		}
		for (int i = 0; i < f1LOverATable.length; i++) {
			f1LOverATable[i] = new TableRow();
		}
		for (int i = 0; i < anaTable.length; i++) {
			anaTable[i] = new TableRow();
		}
		for (int i = 0; i < f1cTable.length; i++) {
			f1cTable[i] = new TableRow();
		}
		for (int i = 0; i < anK2Table.length; i++) {
			anK2Table[i] = new TableRow();
		}
		for (int i = 0; i < anfnTable.length; i++) {
			anfnTable[i] = new TableRow();
		}
	}

	public double Val;
	public double Lc_al;
	public double HelmholtzZeroAreaFrequency;

	public double Vab;
	public double Lc_ab;

	public double f1Min;
	public double f1Max;
	public double f2RetroflexMax;
	public double f3RetroflexMax;
	public double f2LateralMax;
	public double f3LateralMin;
	public double Kacl;
	public double aclFreq;

	public double Vacd;
	public double Lc_acd;
	public double acdMax;
	public double acd_f1Break;
	public double KHi;
	public double f1HiShift;

	public double fno;
	public double anfnTable_fno;
	public double fm_f1BreakPoint;
	public double BNZ_f1BreakPoint;

	public TableRow anK2Table[];
	public TableRow anaTable[];
	public TableRow anbTable[];
	public TableRow anfnTable[];
	public TableRow f1LOverATable[];
	public TableRow f1cTable[];

	public double NasalBandwidth;
	public double BNP_B1_anLow;
	public double BNP_B1_anHigh;
	public double fp_f2BreakPoint;

	public double PharangealArea;

	public double Cwm;
	public double Rw;
	public double Psm;
	public double Cgm;
	public double Lg;

	public double NewtonInterpTimeStep;
	public double UpdateInterval;

	public double LabialAB;
	public double PalVelarA2F;
	public double PalVelarA5F;
	public double PalVelarA3F;
	public double PalVelar_f2Offset;
	public double PalVelar_f2Overf3_Slope;
	public double RetroflexA3F;
	public double LateralA3F;

	public FricativeGains alveolar[][];

	public double B2F;
	public double B3F;
	public double B4F;
	public double B5F;

	public double agm;
	public double agAVModalOffsetMax;
	public double agAVModalOffsetOnOff;
	public double agMin;
	public double agHiKLSourceCutoff;
	public double AVPressureThreshold;
	public double Kv;
	public double KdAV0;
	public double KdAV;
	public double KdAV1;
	public double Ka;

	public double Kf;
	public double AFInterpTimeStep;
	public double AFThreshold;

	public double OQm;
	public double KOQ;
	public double OQMax;
	public double OQMin;

	public double TLBreakArea;
	public double KTL;
	public double TLm;
	public double SFromf4;
	public double SDefault;
	public double PctSfordBTL;
	public double dBTLforPctS;
	public double TLMax;
	public double TLMin;

	public double agDIMin;
	public double KDI;

	public double KdF;
	public double F1T;

	public double B1m;
	public double B2m;
	public double B3m;
	public double B4m;
	public double B5m;
	/*
	 * public double KB1; public double KB2;
	 */
	public double KB3;
	public double KB4;
	public double KB5;

	public double F5;

	public double A6F;
	public double F6;
	public double B6F;

	public double KCw;
	public double KCg;
	public double Kdf0dc;
	public double Kpd;
	public double Kf1;
	public double f1_neutral;
	public double KdPTdc;
	public double f0_vowelshift_f1_break;
	public double Lt;
	public double At;
	public double Lvg;
	public double Lv;
	public double Av;
	public double Lhp;
	
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	public HLSpeaker cloneManual() throws CloneNotSupportedException{
		
		HLSpeaker c = (HLSpeaker) clone();
		
		for (int i = 0; i < alveolar.length; i++) {
			for (int j = 0; j < alveolar[i].length; j++)
				c.alveolar[i][j] = (FricativeGains) alveolar[i][j].clone();
		}
		
		for (int i = 0; i < c.anaTable.length; i++) {
			c.anaTable[i] = (TableRow) anaTable[i].clone();
		}
		for (int i = 0; i < c.anbTable.length; i++) {
			c.anbTable[i] = (TableRow) anbTable[i].clone();
		}
		for (int i = 0; i < c.anfnTable.length; i++) {
			c.anfnTable[i] = (TableRow) anfnTable[i].clone();
		}
		for (int i = 0; i < c.anK2Table.length; i++) {
			c.anK2Table[i] = (TableRow) anK2Table[i].clone();
		}
		for (int i = 0; i < c.f1cTable.length; i++) {
			c.f1cTable[i] = (TableRow) f1cTable[i].clone();
		}
		for (int i = 0; i < c.f1LOverATable.length; i++) {
			c.f1LOverATable[i] = (TableRow) f1LOverATable[i].clone();
		}
		
		return c;
		
	}
}
