package com.laps.jhlsyn.pogo;

import java.io.Serializable;


public class TSpeakerDef implements Serializable, Cloneable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public HLSpeaker speaker;
	public Speaker llspeaker;

	public TSpeakerDef() {
		speaker = new HLSpeaker();
		llspeaker = new Speaker();
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	
	public TSpeakerDef cloneManual() throws CloneNotSupportedException{
		TSpeakerDef c = (TSpeakerDef) clone();
		
		c.speaker = (HLSpeaker) speaker.cloneManual();
		c.llspeaker = (Speaker) llspeaker.clone();
		
		return c;
	}
}
