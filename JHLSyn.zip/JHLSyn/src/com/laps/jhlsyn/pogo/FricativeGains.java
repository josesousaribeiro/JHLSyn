package com.laps.jhlsyn.pogo;

import java.io.Serializable;

public class FricativeGains implements Serializable, Cloneable{

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public double A2F;
	public double A3F;
	public double A4F;
	public double A5F;
	public double AB;



	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
}
