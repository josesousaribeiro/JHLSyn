package com.laps.jhlsyn.pogo;

import java.io.Serializable;

import com.laps.jhlsyn.synth;

public class LLSynth implements Serializable, Cloneable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Synthesizer state;
	public Coefficients coefs;
	public Speaker spkr;
	public Resonator glottal_pulse, spectral_tilt, nasal_pole_cascade,
			formant_1_cascade, formant_2_cascade, formant_3_cascade,
			formant_4_cascade, formant_5_cascade, formant_6_cascade,
			formant_7_cascade, formant_8_cascade, formant_2_parallel,
			formant_3_parallel, formant_4_parallel, formant_5_parallel,
			formant_6_parallel, trach_pole_cascade, formant_1_special,
			formant_2_special, formant_3_special, formant_4_special,
			nasal_pole_special, trach_pole_special;
	public Resonator nasal_zero_cascade, trach_zero_cascade; /* anti-resonators */
	public double out[];

	public LLSynth() {

		state = new Synthesizer();
		coefs = new Coefficients();
		spkr = new Speaker();
		glottal_pulse = new Resonator();
		spectral_tilt = new Resonator();
		nasal_pole_cascade = new Resonator();
		formant_1_cascade = new Resonator();
		formant_2_cascade = new Resonator();
		formant_3_cascade = new Resonator();
		formant_4_cascade = new Resonator();
		formant_5_cascade = new Resonator();
		formant_6_cascade = new Resonator();
		formant_7_cascade = new Resonator();
		formant_8_cascade = new Resonator();
		formant_2_parallel = new Resonator();
		formant_3_parallel = new Resonator();
		formant_4_parallel = new Resonator();
		formant_5_parallel = new Resonator();
		formant_6_parallel = new Resonator();
		trach_pole_cascade = new Resonator();
		formant_1_special = new Resonator();
		formant_2_special = new Resonator();
		formant_3_special = new Resonator();
		formant_4_special = new Resonator();
		nasal_pole_special = new Resonator();
		trach_pole_special = new Resonator();
		nasal_zero_cascade = new Resonator();
		trach_zero_cascade = new Resonator();

		out = new double[synth.NUM_OUTPUTS];
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	
	public LLSynth cloneManual() throws CloneNotSupportedException{
		LLSynth c = (LLSynth) clone();
		
		c.coefs = (Coefficients) coefs.clone();
		c.formant_1_cascade = (Resonator) formant_1_cascade.cloneManual();
		c.formant_1_special = (Resonator) formant_1_special.cloneManual();
		c.formant_2_cascade = (Resonator) formant_2_cascade.cloneManual();
		c.formant_2_parallel = (Resonator) formant_2_parallel.cloneManual();
		c.formant_2_special = (Resonator) formant_2_special.cloneManual();
		c.formant_3_cascade = (Resonator) formant_3_cascade.cloneManual();
		c.formant_3_parallel = (Resonator) formant_3_parallel.cloneManual();
		c.formant_3_special = (Resonator) formant_3_special.cloneManual();
		c.formant_4_cascade = (Resonator) formant_4_cascade.cloneManual();
		c.formant_4_parallel = (Resonator) formant_4_parallel.cloneManual();
		c.formant_4_special =  (Resonator) formant_4_special.cloneManual();
		c.formant_5_cascade = (Resonator) formant_5_cascade.cloneManual();
		c.formant_5_parallel = (Resonator) formant_5_parallel.cloneManual();
		c.formant_6_cascade = (Resonator) formant_6_cascade.cloneManual();
		c.formant_6_parallel = (Resonator) formant_6_parallel.cloneManual();
		c.formant_7_cascade = (Resonator) formant_7_cascade.cloneManual();
		c.formant_8_cascade = (Resonator) formant_8_cascade.cloneManual();
		c.glottal_pulse = (Resonator) glottal_pulse.cloneManual();
		c.nasal_pole_cascade = (Resonator) nasal_pole_cascade.cloneManual();
		c.nasal_pole_special = (Resonator) nasal_pole_special.cloneManual();
		c.nasal_zero_cascade = (Resonator) nasal_zero_cascade.cloneManual();
		c.spectral_tilt = (Resonator) spectral_tilt.cloneManual();
		c.spkr = (Speaker) spkr.clone();
		c.state =  (Synthesizer) state.clone();
		c.trach_pole_cascade = (Resonator) trach_pole_cascade.cloneManual();
		c.trach_pole_special = (Resonator) trach_pole_special.cloneManual();
		c.trach_zero_cascade = (Resonator) trach_zero_cascade.cloneManual();
	
		
		
		return c;
	}
	
	
}
