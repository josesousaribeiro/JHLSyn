package com.laps.jhlsyn.pogo;

import java.io.Serializable;

public class Resonator implements Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Coef coef;
	private State state;

	public class Coef implements Serializable,Cloneable {

		private static final long serialVersionUID = 1L;
		public double A = 0, B = 0, C = 0;
		
		@Override
		protected Object clone() throws CloneNotSupportedException {
			// TODO Auto-generated method stub
			return super.clone();
		}
	};

	public class State implements Serializable,Cloneable {
		private static final long serialVersionUID = 1L;
		public double Z1 = 0, Z2 = 0;
		
		@Override
		protected Object clone() throws CloneNotSupportedException {
			// TODO Auto-generated method stub
			return super.clone();
		}
	};

	public Resonator() {
		this.coef = new Coef();
		this.state = new State();
	}

	public Coef getCoef() {
		return coef;
	}

	public void setCoef(Coef coef) {
		this.coef = coef;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	
	public Resonator cloneManual() throws CloneNotSupportedException{
		Resonator c = (Resonator) clone();
		c.coef = (Coef) coef.clone();
		c.state = (State) state.clone();
		return c;
	}
}
