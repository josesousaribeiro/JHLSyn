package com.laps.jhlsyn.pogo;

import java.io.Serializable;

public class TableRow implements Serializable, Cloneable{
	  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public double Column1;
	  public double Column2;
	  
	// #define MAXANFN 9
		// #define ANFN_AN Column1
		// #define ANFN_FN Column2

		public void ANFN_AN(float x) {
			this.Column1 = x;
		}

		public void ANFN_FN(float x) {
			this.Column2 = x;
		}

		// #define MAXF1LOVERA 11
		// #define F1LOVERA_F1 Column1
		// #define F1LOVERA_LOVERA Column2
		public void F1LOVERA_F1(float f) {
			this.Column1 = f;
		}

		public void F1LOVERA_LOVERA(float f) {
			this.Column2 = f;

		}

		// #define MAXANA 6
		// #define ANA_AN Column1
		// #define ANA_A Column2
		public void ANA_AN(float f) {
			this.Column1 = f;
		}

		public void ANA_A(float f) {
			this.Column2 = f;

		}

		// #define MAXANB 6
		// #define ANB_AN Column1
		// #define ANB_B Column2
		public void ANB_AN(float f) {
			this.Column1 = f;
		}

		public void ANB_B(float f) {
			this.Column2 = f;

		}

		// #define MAXF1C 7
		// #define F1C_F1 Column1
		// #define F1C_C Column2
		public void F1C_F1(float f) {
			this.Column1 = f;
		}
		public void F1C_C(float f) {
			this.Column2 = f;

		}
		
		
		// #define MAXANK2 17
		// #define ANK2_AN Column1
		// #define ANK2_K2 Column2
		public void ANK2_AN(float f) {
			this.Column1 = f;
		}
		public void ANK2_K2(float f) {
			this.Column2 = f;

		}
	  
		@Override
		public Object clone() throws CloneNotSupportedException {
			// TODO Auto-generated method stub
			return super.clone();
		}
	}