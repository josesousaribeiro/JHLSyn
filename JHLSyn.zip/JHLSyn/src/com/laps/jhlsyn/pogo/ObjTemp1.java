package com.laps.jhlsyn.pogo;

import java.io.Serializable;

public class ObjTemp1 implements Serializable, Cloneable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public double Brac_low;
	public double Brac_high;
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
}