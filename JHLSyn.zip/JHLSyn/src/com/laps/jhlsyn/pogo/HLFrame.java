package com.laps.jhlsyn.pogo;

import java.io.Serializable;

public class HLFrame implements Cloneable, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public double ag; /* mm^2 */
	public double al; /* mm^2 */
	public double ab; /* mm^2 */
	public double an; /* mm^2 */
	public double ue; /* cm^3/s */
	public double f0; /* deciHz */
	public double f1; /* Hz */
	public double f2; /* Hz */
	public double f3; /* Hz */
	public double f4; /* Hz */
	public double ps; /* cm H20 */
	public double dc; /* % */
	public double ap; /* mm^2 */

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

}
