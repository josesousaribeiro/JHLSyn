package com.laps.jhlsyn.pogo;

import java.io.Serializable;

public class Speaker implements Cloneable, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int DU;
	public int UI;
	public int SR;
	public int NF;
	public int SS;
	public int RS;
	public int SB;
	public int CP;
	public int OS;
	public int GV;
	public int GH;
	public int GF;
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	
}
