package com.laps.jhlsyn.pogo;

import java.io.Serializable;

public class LLFrame implements Serializable, Cloneable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int F0;
	public int AV;
	public int OQ;
	public int SQ;
	public int TL;
	public int FL;
	public int DI;
	public int AH;
	public int AF;

	public int F1;
	public int B1;
	public int DF1;
	public int DB1;
	public int F2;
	public int B2;
	public int F3;
	public int B3;
	public int F4;
	public int B4;
	public int F5;
	public int B5;
	public int F6;
	public int B6;

	public int FNP;
	public int BNP;
	public int FNZ;
	public int BNZ;
	public int FTP;
	public int BTP;
	public int FTZ;
	public int BTZ;

	public int A2F;
	public int A3F;
	public int A4F;
	public int A5F;
	public int A6F;
	public int AB;
	public int B2F;
	public int B3F;
	public int B4F;
	public int B5F;
	public int B6F;

	public int ANV;
	public int A1V;
	public int A2V;
	public int A3V;
	public int A4V;
	public int ATV;
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
}
