package com.laps.jhlsyn.pogo;

import java.io.Serializable;

public class FNPVars implements Serializable, Cloneable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/* Define a structure for the useful values in NasalPole */
	
	
	  private double K1;
	  private double K2;
	  private double fn;
	  private double fp;
	  private double f1c;
	public double getK1() {
		return K1;
	}
	public void setK1(double k1) {
		K1 = k1;
	}
	public double getK2() {
		return K2;
	}
	public void setK2(double k2) {
		K2 = k2;
	}
	public double getFn() {
		return fn;
	}
	public void setFn(double fn) {
		this.fn = fn;
	}
	public double getFp() {
		return fp;
	}
	public void setFp(double fp) {
		this.fp = fp;
	}
	public double getF1c() {
		return f1c;
	}
	public void setF1c(double f1c) {
		this.f1c = f1c;
	}
	  
	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	  
	  
	  
}
