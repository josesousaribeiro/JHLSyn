package com.laps.jhlsyn;

import com.laps.jhlsyn.pogo.FNPVars;
import com.laps.jhlsyn.pogo.PmRootFunctionArgs;

public class brent {
	/*****************************************************************************/
	/** HLsyn - Version 2.2 **/
	/**                                                                         **/
	/** Copyright (c) 1993-1997 by Sensimetrics Corporation **/
	/** All rights reserved. **/
	/**                                                                         **/
	/*****************************************************************************/

	/*
	 * brent.c - general implementation of Brent's algorithm (and supporting
	 * utilities)
	 * 
	 * 6 Oct 1997 reb: Split off from circuit.c and nasalf1x.c; unified the
	 * special-purpose Brent routines in those files into general-purpose
	 * routines.
	 */

	public static int BrentBracket(PmRootFunctionArgs othersArgs, double x1,
			double x2, double factor, int ntry) {
		int j;
		double f1, f2;

		f1 = circuit.PmRootFunction(x1, othersArgs);
		f2 = circuit.PmRootFunction(x2, othersArgs);

		for (j = 1; j <= ntry; j++) {
			if (f1 * f2 < 0.0)
				return 1;

			if (Math.abs(f1) < Math.abs(f2))
				f1 = circuit.PmRootFunction(x1 += factor * (x1 - x2),
						othersArgs);
			else
				f2 = circuit.PmRootFunction(x2 += factor * (x2 - x1),
						othersArgs);
		}

		return 0;
	}

	public static double Brent(PmRootFunctionArgs othersArgs, double x1,
			double x2, double tol, int itmax, double eps)

	/*****
	 * From Numerical Recipes in C, page 268. Using Brent's method, find the
	 * root of a function known to lie between x1 and x2. The root will be
	 * refined until its accuracy is tol.
	 *****/

	{
		int iter;
		double a = x1, b = x2, c = 0, d = 0, e = 0, min1, min2;
		double fa = circuit.PmRootFunction(a, othersArgs);
		double fb = circuit.PmRootFunction(b, othersArgs);
		double fc, p, q, r, s, tol1, xm;

		fc = fb;
		for (iter = 1; iter <= itmax; iter++) {
			if (fb * fc > 0.0) {

				/*****
				 * Rename a,b,c and adjust bounding interval d.
				 *****/

				c = a;
				fc = fa;
				e = d = b - a;
			}

			if (Math.abs(fc) < Math.abs(fb)) {
				a = b;
				b = c;
				c = a;
				fa = fb;
				fb = fc;
				fc = fa;
			}

			tol1 = (double) (2.0 * eps * Math.abs(b) + 0.5 * tol); /*
																	 * Convergence
																	 * check
																	 */
			xm = (double) (0.5 * (c - b));

			if (Math.abs(xm) <= tol1 || fb == 0.0)
				return b;
			if (Math.abs(e) >= tol1 && Math.abs(fa) > Math.abs(fb)) {

				/*****
				 * Attempt inverse quadratic interpolation
				 *****/

				s = fb / fa;
				if (a == c) {
					p = (double) (2.0 * xm * s);
					q = (double) (1.0 - s);
				} else {
					q = fa / fc;
					r = fb / fc;
					p = (double) (s * (2.0 * xm * q * (q - r) - (b - a)
							* (r - 1.0)));
					q = (double) ((q - 1.0) * (r - 1.0) * (s - 1.0));
				}
				if (p > 0.0) /* Check whether in bounds */
					q = -q;
				p = (double) Math.abs(p);
				min1 = (double) (3.0 * xm * q - Math.abs(tol1 * q));
				min2 = (double) Math.abs(e * q);
				if (2.0 * p < (min1 < min2 ? min1 : min2)) {
					e = d; /* Accept interpolation */
					d = p / q;
				} else {
					/*****
					 * Interpolation failed, use bisection.
					 *****/
					d = xm;
					e = d;
				}
			} else {
				/*****
				 * Bounds decreasing too slowly, use bisection.
				 *****/
				d = xm;
				e = d;
			}
			a = b; /* Move last best guess to a. */
			fa = fb;
			if (Math.abs(d) > tol1) /* evaluate new trial root. */
				b += d;
			else
				b += (double) (xm > 0.0 ? Math.abs(tol1) : -Math.abs(tol1));

			fb = circuit.PmRootFunction(b, othersArgs);
		}

		if (x1 < x2)
			return x2 + 1; /* error code, return out of bounds */
		else
			return x2 - 1;
	}

	public static double Brent(FNPVars fNPVars, double x1, double x2,
			double tol, int itmax, double eps)

	/*****
	 * From Numerical Recipes in C, page 268. Using Brent's method, find the
	 * root of a function known to lie between x1 and x2. The root will be
	 * refined until its accuracy is tol.
	 *****/

	{
		int iter;
		double a = x1, b = x2, c = 0, d = 0, e = 0, min1, min2;
		double fa = nasalf1x.SusceptanceSum((double) x1, fNPVars);
		double fb = nasalf1x.SusceptanceSum((double) x2, fNPVars);
		double fc, p, q, r, s, tol1, xm;

		fc = fb;
		for (iter = 1; iter <= itmax; iter++) {
			if (fb * fc > 0.0) {

				/*****
				 * Rename a,b,c and adjust bounding interval d.
				 *****/

				c = a;
				fc = fa;
				e = d = b - a;
			}

			if (Math.abs(fc) < Math.abs(fb)) {
				a = b;
				b = c;
				c = a;
				fa = fb;
				fb = fc;
				fc = fa;
			}

			tol1 = (double) (2.0 * eps * Math.abs(b) + 0.5 * tol); /*
																	 * Convergence
																	 * check
																	 */
			xm = (double) (0.5 * (c - b));

			if (Math.abs(xm) <= tol1 || fb == 0.0)
				return b;
			if (Math.abs(e) >= tol1 && Math.abs(fa) > Math.abs(fb)) {

				/*****
				 * Attempt inverse quadratic interpolation
				 *****/

				s = fb / fa;
				if (a == c) {
					p = (double) (2.0 * xm * s);
					q = (double) (1.0 - s);
				} else {
					q = fa / fc;
					r = fb / fc;
					p = (double) (s * (2.0 * xm * q * (q - r) - (b - a)
							* (r - 1.0)));
					q = (double) ((q - 1.0) * (r - 1.0) * (s - 1.0));
				}
				if (p > 0.0) /* Check whether in bounds */
					q = -q;
				p = (double) Math.abs(p);
				min1 = (double) (3.0 * xm * q - Math.abs(tol1 * q));
				min2 = (double) Math.abs(e * q);
				if (2.0 * p < (min1 < min2 ? min1 : min2)) {
					e = d; /* Accept interpolation */
					d = p / q;
				} else {
					/*****
					 * Interpolation failed, use bisection.
					 *****/
					d = xm;
					e = d;
				}
			} else {
				/*****
				 * Bounds decreasing too slowly, use bisection.
				 *****/
				d = xm;
				e = d;
			}
			a = b; /* Move last best guess to a. */
			fa = fb;
			if (Math.abs(d) > tol1) /* evaluate new trial root. */
				b += d;
			else
				b += (double) (xm > 0.0 ? Math.abs(tol1) : -Math.abs(tol1));

			fb = nasalf1x.SusceptanceSum((double) b, fNPVars);
		}

		if (x1 < x2)
			return x2 + 1; /* error code, return out of bounds */
		else
			return x2 - 1;
	}
}
