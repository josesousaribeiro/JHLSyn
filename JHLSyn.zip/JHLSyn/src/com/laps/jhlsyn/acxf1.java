package com.laps.jhlsyn;

import com.laps.jhlsyn.pogo.HLFrame;
import com.laps.jhlsyn.pogo.HLSpeaker;
import com.laps.jhlsyn.pogo.HLState;

public abstract class acxf1 {

	/*****************************************************************************/
	/** HLsyn - Version 2.2 **/
	/**                                                                         **/
	/** Copyright (c) 1993-1996 by Sensimetrics Corporation **/
	/** All rights reserved. **/
	/**                                                                         **/
	/*****************************************************************************/

	/*
	 * acxf1c.c - compute acx,f1c
	 * 
	 * coded by J. Erik Moore, 12/93
	 * 
	 * Modification History:
	 * 
	 * 27 Aug 1996 reb: include flavor.h 08 Aug 1996 reb: archived as version
	 * 2.2 (no changes).
	 */

	final static double UNCOMPUTABLE = -1.f;

	/*****
	 * Function declarations.
	 *****/

	static void Tongue_acx_f1c(HLFrame frame, HLSpeaker speaker, HLState state) {
		double R1al, R1ab;

		/*****
		 * Compute the area adjusted f1, which is the minimum f1 of f1,R1al, and
		 * R1ab.
		 *****/

		R1al = HelmholtzFrequency(hlsyn.MMSQ_TO_CMSQ(frame.al), speaker.Val,
				speaker.Lc_al, speaker.HelmholtzZeroAreaFrequency);

		/*****
		 * There may be some additional modification here due to alveopalatal or
		 * dental. It is discussed in the chapter on page 34.
		 *****/

		R1ab = HelmholtzFrequency(hlsyn.MMSQ_TO_CMSQ(frame.ab), speaker.Vab,
				speaker.Lc_ab, speaker.HelmholtzZeroAreaFrequency);

		if (R1al < R1ab && R1al < frame.f1)
			state.f1c = R1al;

		else if (R1ab < R1al && R1ab < frame.f1)
			state.f1c = R1ab;

		else
			state.f1c = frame.f1;

		/*****
		 * Compute the minimum constriction area (acx) and its location (loc)
		 * which is the minimum of acl,acd,al and ab.
		 *****/

		state.acl = Compute_acl(frame, speaker);
		state.acd = Compute_acd(frame, speaker);

		Set_acx_loc(frame, state);
	}

	static double HelmholtzFrequency(double d, double val, double lc_al,
			double helmholtzZeroAreaFrequency)

	{
		double temp;

		/*****
		 * This routine expects CGS units.
		 *****/

		temp = (double) (hlsyn.SPEEDSOUND * hlsyn.SPEEDSOUND * d / (4.
				* hlsyn.PI * hlsyn.PI * val * lc_al));
		return (double) Math.sqrt(temp + helmholtzZeroAreaFrequency
				* helmholtzZeroAreaFrequency);
	}

	static double HelmholtzConstriction(double LowestNaturalFrequency,
			double vacd, double lc_acd, double helmholtzZeroAreaFrequency) {
		double temp;

		/*****
		 * This routine expects CGS units.
		 *****/

		temp = (double) (vacd * lc_acd * 4. * hlsyn.PI * hlsyn.PI / (hlsyn.SPEEDSOUND * hlsyn.SPEEDSOUND));

		return (double) ((LowestNaturalFrequency * LowestNaturalFrequency - helmholtzZeroAreaFrequency
				* helmholtzZeroAreaFrequency) * temp);
	}

	static double Compute_acl(HLFrame frame, HLSpeaker speaker) {
		if ((speaker.f1Min < frame.f1 && frame.f1 < speaker.f1Max)
				&& ((frame.f2 < speaker.f2RetroflexMax && frame.f3 < speaker.f3RetroflexMax) || (frame.f2 < speaker.f2LateralMax && frame.f3 > speaker.f3LateralMin))) {
			/*****
			 * Cannot be negative if all values are positive
			 *****/
			return (double) ((frame.f1 / speaker.aclFreq)
					* (frame.f1 / speaker.aclFreq) * speaker.Kacl);
		} else {
			return UNCOMPUTABLE;
		}
	}

	static double Compute_acd(HLFrame frame, HLSpeaker speaker) {
		double acd, temp;

		/*****
		 * This routine will generate figure 2.10 and comments from Ken Stevens.
		 * It does not exactly match the text in the December 93 version of the
		 * chapter.
		 * 
		 * Units in this routine are mixed. The Helmholtz routine uses CGS. The
		 * higer frequency portion gives mm^2 using the constants given in the
		 * chapter.
		 *****/

		if (frame.f1 < speaker.acd_f1Break) {
			acd = HelmholtzConstriction(frame.f1, speaker.Vacd, speaker.Lc_acd,
					speaker.HelmholtzZeroAreaFrequency);
			acd = (double) hlsyn.CMSQ_TO_MMSQ(acd); /* Convert to mm^2 */
		} else {
			temp = (double) ((speaker.f1HiShift - frame.f1) / speaker.HelmholtzZeroAreaFrequency);
			acd = (double) (speaker.KHi * temp * temp - speaker.KHi);
		}

		return acd;
	}

	static void Set_acx_loc(HLFrame frame, HLState state)

	{
		double LiquidDorsumArea, LipsBladeArea;
		int LiquidDorsumPlace, LipsBladePlace;

		/*****
		 * In this routine the location of the smallest area and the size of the
		 * smallest area are set. If two areas are equal then the one that is
		 * furthest back from the lips is used.
		 *****/

		/*****
		 * Sort through the Liquid and Dorsum areas first.
		 *****/

		if (state.acl == UNCOMPUTABLE) {
			LiquidDorsumArea = state.acd;
			LiquidDorsumPlace = hlsyn.DORSUM;
		}

		else if (state.acd <= state.acl) {
			LiquidDorsumArea = state.acd;
			LiquidDorsumPlace = hlsyn.DORSUM;
		}

		else {
			LiquidDorsumArea = state.acl;
			LiquidDorsumPlace = hlsyn.LIQUID;
		}

		/*****
		 * Sort through the lips and blade next.
		 *****/

		if (frame.ab <= frame.al) {
			LipsBladeArea = frame.ab;
			LipsBladePlace = hlsyn.BLADE;
		}

		else {
			LipsBladeArea = frame.al;
			LipsBladePlace = hlsyn.LIPS;
		}

		/*****
		 * Finally, set the loc and acx. acx will be positive.
		 *****/

		if (LiquidDorsumArea <= LipsBladeArea) {
			state.acx = LiquidDorsumArea;
			state.loc = LiquidDorsumPlace;
		}

		else {
			state.acx = LipsBladeArea;
			state.loc = LipsBladePlace;
		}
	}
}
