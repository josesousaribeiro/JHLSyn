package com.laps.jhlsyn.MAIN;

import java.io.IOException;

import com.laps.jhlsyn.JHLSyn_for_frame;
import com.laps.jhlsyn.JHLSyn_for_frames;
import com.laps.jhlsyn.util.Util;

public class Main_Synthesizer {

	final static int MODE_WRITE_FILE = 1;
	final static int MODE_NO_WRITE_FILE = 0;

	static String path_wave_out = "hldata2.raw";
	static String path_hl_in = "hldata2.hlsyn";

	static int i;

	static JHLSyn_for_frames hlframe = null;

	public static void main(String[] args) throws CloneNotSupportedException,
			InterruptedException, IOException {

		if (args.length == 1) {
			path_hl_in = args[0];
			path_wave_out = args[0].replace(".hlsyn", ".raw");
		} 
		else {
			System.err.println("Command expected: Main <path_hlfile.hlsyn>");
		}

		hlframe = new JHLSyn_for_frames(71, 11025,path_wave_out,MODE_WRITE_FILE);

		final int hl_mat[][] = Util.readHLSynFile(path_hl_in);

		
		hlframe.runByFrames(hl_mat);
		
	}

}
