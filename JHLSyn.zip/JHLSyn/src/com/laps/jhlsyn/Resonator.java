package com.laps.jhlsyn;


public class Resonator {
	
	private Coef coef;
	private State state;
	
	class Coef { double A=0, B=0, C=0;};
	class State { double Z1=0, Z2=0;};
	
	
	public Resonator() {
		this.coef = new Coef();
		this.state = new State();
	}


	public Coef getCoef() {
		return coef;
	}


	public void setCoef(Coef coef) {
		this.coef = coef;
	}


	public State getState() {
		return state;
	}


	public void setState(State state) {
		this.state = state;
	}		
}
