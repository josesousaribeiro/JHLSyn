package com.laps.jhlsyn;

import com.laps.jhlsyn.pogo.FricativeGains;
import com.laps.jhlsyn.pogo.HLSpeaker;


public class hlsyn {
	
	/*****************************************************************************/
	/**  HLsyn - Version 2.2                                                    **/
	/**                                                                         **/
	/** Copyright (c) 1993-1998 by Sensimetrics Corporation                     **/
	/** All rights reserved.                                                    **/
	/**                                                                         **/
	/*****************************************************************************/

	/*
	 *  hlsyn.h
	 *
	 *  coded by J. Erik Moore, 12/93
	 *
	 *  Modification History:
	 *
	 *  25 Mar 1998  reb:  added MAX, MIN.
	 *   6 Oct 1997  reb:  removed REMOVE_NASAL_POLE_ZERO; added definition of 
	 *                     the interface to brent.c, moved FNPVars definition to
	 *                     nasalf1x.c, added AN_NO_NASAL_BREAKPOINT, parenthesized 
	 *                     a few preprocessor variables.
	 *  30 Apr 1997  reb:  added dynamic viscosity MU of air; added Lhp (horizontal 
	 *                     length of the posterior glottal chink) to HL speaker; 
	 *                     added FLOW_SQRT macro; used HLSYNAPI rather than FLAV_STDCALL; 
	 *                     added FLOAT_EPS (and so included float.h).
	 *  22 Nov 1996  reb:  moved ps from HLSpeaker to HLFrame, changed instances 
	 *                     of Ps to ps to reflect this; added dc and ap to HLFrame, 
	 *                     KCw, KCg, Kdf0dc, Kpd, Kf1, f1_neutral, KdPTdc, 
	 *                     f0_vowelshift_f1_break, Psm, Cwm, Cgm, Lt, At, Lvg, Lv, 
	 *                     and Av to HLSpeaker, moved Cw and Cg from HLSpeaker 
	 *                     to HLState, and added agf to HLState; removed KB1 and 
	 *                     KB2 from HLSpeaker; added length epsilon L_EPS.  
	 *  27 Aug 1996  reb:  added agHiKLSourceCutoff, AVPressureThreshold, 
	 *                     KdAV0, KdAV1 to HLSpeaker; added 
	 *                     REMOVE_NASAL_POLE_ZERO; included flavor.h, 
	 *                     checked FLAV_STDCALL in decl's of 
	 *                     HLSynthesizeLLFrame, InitializeHLSynthesizer; 
	 *                     added AGHIKLSOURCECUTOFF_VAL and ..._STRING.
	 *  08 Aug 1996  reb:  archived as version 2.2 (no changes).
	 *  17 Oct 1995  changed ALV_F3_MAX from 3500 to 3600 (for female) (epc)
	 *   2 Oct 1995  added () around parameters in unit conversion macros (epc)
	 *  21 Sep 1995  changed ALV_RESOLUTION back to 50 (epc)
	 *  20 Sep 1995  changed ALV_RESOLUTION from 50 to 25 (epc)
	 */

	
	

	
	
	


	final static int LINE_LEN =  100;

	final static int NO = 0;
	final static int YES = 1;

	public static double MAX( double x, double y){
		return ((x) > (y) ?  (x) : (y));
	}
	public double MIN(double x, double y){
		return ((x) < (y) ?  (x) : (y));
	}

	/*****
		These are used to remove pole zero pairs by setting them equal
		to one another so that they cancel out.
	*****/

	final static int REMOVE_FORMANT = 1000;		/* Any constant (value not important) */ 
	final static int REMOVE_BANDWIDTH = 200;	/* Any constant (value not important) */

	/*****
		The units in the code are mostly in CGS.  However, the areas
		are specified in mm^2 and the subglottal pressure (ps) is in
		cmH20.  These are the conversion macros.
	*****/

	public static double CMWATER_TO_CGS( double CMWATER) {
		return ((CMWATER)*980.0f);
	}
	public static double CGS_TO_CMWATER(double CGS){
		return ((CGS)/980.0f);
	}
	public static double CMSQ_TO_MMSQ( double CMSQ){
		return ((CMSQ)*100.0f);
	}
	public static double MMSQ_TO_CMSQ( double MMSQ) {
		return ((MMSQ)*0.01f);
	}

	public static double FLOW_SQRT( double X) {
		return ((X) < 0.0 ?  -Math.sqrt(-(X)) : Math.sqrt((X)));
	}

	final static double L_EPS = 0.001f; /* cm */
	final static double FLOAT_EPS = (10.0f * Float.MIN_NORMAL);

	final static double AN_NO_NASAL_BREAKPOINT = (-0.5f); /* sq. mm */

	final static double AGHIKLSOURCECUTOFF_VAL = 30.0f; /* sq. mm */
	final static String AGHIKLSOURCECUTOFF_STRING= "30.0";
	
	
//	static double AGHIKLSOURCECUTOFF_VAL = 99999.0f; /* sq. mm */
//	static String AGHIKLSOURCECUTOFF_STRING= "99999.0";
	
	
	

	

	/* Interface to the Brent's algorithm routines in brent.c */
	final static int BRENT_DEFAULT_ITMAX = 100;	   /* Max allowed iterations */
	final static double BRENT_DEFAULT_EPS = 3.0e-8f;	   /* Machine floating point precision */
	final static double BRENT_BRACKET_DEFAULT_FACTOR = 1.6f; /* Interval expansion factor */
	final static int BRENT_BRACKET_DEFAULT_NTRY = 50; /* Max allowed interval expansions */

	
	/*****
	All the areas in the state are in mm^2
	*****/

	

	

	final static int SPEEDSOUND = 35400;	/* cm/s */
	final static double PI = 3.14159265359f;
	final static double RHO = 0.00114f;		/* g/cm^3 */
	final static double MU = 0.000194f;  /* dyne sec/cm^4 */

	static final int LIPS = 1;
	static final int BLADE = 2;
	static final int DORSUM = 3;
	static final int LIQUID = 4;

	/*****
	This is a first pass at a nice way to use tables.  An entry
	is typedef'ed and then each of the tables are defined with
	lengths and nmonics for the entries.  NOTE: IT IS IMPORTANT
	THAT THE KNOWN ELEMENT IS COLUMN 1 AND THE UNKNOWN IS COLUMN 2.
	This is necessary when searching the tables.
	*****/

	

	
	public final static int MAXANFN = 9;

	public final static int MAXF1LOVERA = 11;

	public final static int MAXANA = 6;

	public final static int MAXANB = 6;

	public final static int MAXF1C = 7;

	public final static int MAXANK2 = 17;
	

	

	/*****
	In this alveolar precompiler stuff I have set the important
	information which is the resolution and the f2,f3 mins and
	maxs.  These are sufficient to compute everything else.  I do
	however realize that the method used will run slowly
	because of the in-line divisions.  I felt that precomputing
	the derived quantities would be leaving one open to errors.

	The ranges are taken from the HLSYN write up as the ranges on the graphs
	*****/

	public final static double ALV_RESOLUTION = 50;	/* Hz */

	public final static int ALV_F2_MIN = 800;		/* Hz */
	public final static double ALV_F2_MAX = 2900;		/* Hz */
	public final static double ALV_F2_POINTS  = (ALV_F2_MAX-ALV_F2_MIN)/ALV_RESOLUTION + 1;

	public final static int ALV_F3_MIN = 1800;		/* Hz */
	public final static double ALV_F3_MAX = 3600;		/* Hz */
	
	public final static double ALV_F3_POINTS = (ALV_F3_MAX-ALV_F3_MIN)/ALV_RESOLUTION + 1;

	public static FricativeGains ALVEOLAR( HLSpeaker speaker, double f2, double f3){
		int index1 = (int) (((f2) - hlsyn.ALV_F2_MIN) / hlsyn.ALV_RESOLUTION);
		int index2 = (int) (((f3) - hlsyn.ALV_F3_MIN) / hlsyn.ALV_RESOLUTION);
		
		return speaker.alveolar[index1][index2];
	}

	

	
}

