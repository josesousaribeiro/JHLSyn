package com.laps.jhlsyn;

import com.laps.jhlsyn.pogo.LLFrame;
import com.laps.jhlsyn.pogo.LLSynth;


public class sample {
	/*****************************************************************************/
	/**  SenSyn - Version 2.2                                                   **/
	/**                                                                         **/
	/**  Copyright (c) 1991-1996 by Sensimetrics Corporation                    **/
	/**  All rights reserved.                                                   **/
	/**                                                                         **/
	/*****************************************************************************/

	static /*
	 *  sample.c - synthesize one sample
	 *
	 *  coded by Eric P. Carlson
	 *
	 *  Modification History:
	 *
	 *    27 Aug 1996 reb:  include flavor.h
	 *    08 Aug 1996 reb:  made floating point constants single-precision;
	 *                      archived as version 2.2.
	 *    21 Sep 1995	use synthesizer out array rather than reallocating
	 *    29 Aug 1993	version 2.0 (library version)
	 *    14 Jan 1993       sign-extend modulo in noise calculation
	 *     8 Jan 1993	corrected modulo arithmetic in noise calculation
	 *    10 Mar 1992	removed aspiration modulation when F0 = 0
	 *     7 Nov 1991	moved voicing source to voice.c
	 *     5 Nov 1991	removed from spyn.c
	 */

	
	
	/* ---------------------------------------------------------------------- */

	double next_sample(LLSynth mSynth, LLFrame frame)
	{
	  double []out;
	  double noise, first_diff, output, special;
	  double casc;

	  
	  out = mSynth.out;

	  out[synth.O_VOICING] = voice.next_voice_sample(mSynth, frame);


	/* ---------------------------------------------------------------------- */
	/* aspiration/frication noise source */
	  noise = (int)(mSynth.state.random = (int) ((mSynth.state.random * 20077L 
		  + 12345L) % 65536L)) / 65536.f;
	  if (frame.F0!=0 && (mSynth.state.glottis_open==0) && mSynth.state.AV!=0)
	    noise /= 2;
	  out[synth.O_ASPIRATION] = mSynth.coefs.asp_amp * noise - mSynth.state.asp_state;
	  mSynth.state.asp_state = mSynth.coefs.asp_amp * noise;
	  out[synth.O_GLOTTAL] = 12.f * out[synth.O_VOICING] + 5.f * out[synth.O_ASPIRATION];
	  out[synth.O_FRICATION] = -(mSynth.coefs.fric_amp * noise);


	/* ---------------------------------------------------------------------- */
	/* cascade synthesis */

	  if (mSynth.state.parallel_only_flag==0) {
	    casc = out[synth.O_NASAL_POLE_CASC] = reson.AdvanceResonator(mSynth.nasal_pole_cascade,
	      out[synth.O_NASAL_ZERO_CASC] = reson.AdvanceAntiResonator(mSynth.nasal_zero_cascade,
	        out[synth.O_TRACHEAL_CASC] = reson.AdvanceResonator(mSynth.trach_pole_cascade,
	        		reson.AdvanceAntiResonator(mSynth.trach_zero_cascade,
					   out[synth.O_GLOTTAL] / 4.f))));
	    switch (mSynth.spkr.NF) {
	      case 8:    casc = reson.AdvanceResonator(mSynth.formant_8_cascade, casc);
	      case 7:    casc = reson.AdvanceResonator(mSynth.formant_7_cascade, casc);
	      case 6:    casc = reson.AdvanceResonator(mSynth.formant_6_cascade, casc);
	      case 5:    casc = out[synth.O_FORMANT_5_CASC] =
			   reson.AdvanceResonator(mSynth.formant_5_cascade, casc);
	      case 4:    casc = out[synth.O_FORMANT_4_CASC] =
			   reson.AdvanceResonator(mSynth.formant_4_cascade, casc);
	      case 3:    casc = out[synth.O_FORMANT_3_CASC] =
			   reson.AdvanceResonator(mSynth.formant_3_cascade, casc);
	      case 2:    casc = out[synth.O_FORMANT_2_CASC] =
			   reson.AdvanceResonator(mSynth.formant_2_cascade, casc);
	      case 1:
	      default:   out[synth.O_FORMANT_1_CASC] =
			   reson.AdvanceResonator(mSynth.formant_1_cascade, casc);
	    }

	    /* if using cascade, clear state of special parallel branch */
	    mSynth.state.glottal_state = first_diff = special = 0.f;
	  }


	/* ---------------------------------------------------------------------- */
	/* special parallel branch */

	  else {

	    first_diff = out[synth.O_GLOTTAL] - mSynth.state.glottal_state;
	    mSynth.state.glottal_state = out[synth.O_GLOTTAL];

	    special = (out[synth.O_NASAL_PARA] = reson.AdvanceResonator(mSynth.nasal_pole_special,
					    out[synth.O_GLOTTAL] * mSynth.coefs.npv_amp))
	            + (out[synth.O_FORMANT_1_PARA] = reson.AdvanceResonator(mSynth.formant_1_special,
					    out[synth.O_GLOTTAL] * mSynth.coefs.f1v_amp))
		    - reson.AdvanceResonator(mSynth.formant_2_special,
			    first_diff * mSynth.coefs.f2v_amp)
		    + reson.AdvanceResonator(mSynth.formant_3_special,
			    first_diff * mSynth.coefs.f3v_amp)
		    - reson.AdvanceResonator(mSynth.formant_4_special,
			    first_diff * mSynth.coefs.f4v_amp)
		    + reson.AdvanceResonator(mSynth.trach_pole_special,
			    first_diff * mSynth.coefs.tpv_amp);
	  }


	/* ---------------------------------------------------------------------- */
	/* parallel synthesis */

	  out[synth.O_FORMANT_2_PARA] = reson.AdvanceResonator(mSynth.formant_2_parallel,
		                     out[synth.O_FRICATION] * mSynth.coefs.f2p_amp);
	  out[synth.O_FORMANT_3_PARA] = reson.AdvanceResonator(mSynth.formant_3_parallel,
		                     out[synth.O_FRICATION] * mSynth.coefs.f3p_amp);
	  out[synth.O_FORMANT_4_PARA] = reson.AdvanceResonator(mSynth.formant_4_parallel,
		                     out[synth.O_FRICATION] * mSynth.coefs.f4p_amp);
	  out[synth.O_FORMANT_5_PARA] = reson.AdvanceResonator(mSynth.formant_5_parallel,
				     out[synth.O_FRICATION] * mSynth.coefs.f5p_amp);
	  out[synth.O_FORMANT_6_PARA] = reson.AdvanceResonator(mSynth.formant_6_parallel,
				     out[synth.O_FRICATION] * mSynth.coefs.f6p_amp);
	  out[synth.O_BYPASS_PARA] = out[synth.O_FRICATION] * mSynth.coefs.bypass_amp;


	/* ---------------------------------------------------------------------- */
	/* normal output */

	  out[synth.O_NORMAL] = out[synth.O_FORMANT_1_CASC] +
			  out[synth.O_FORMANT_2_PARA] - out[synth.O_FORMANT_3_PARA] +
			  out[synth.O_FORMANT_4_PARA] - out[synth.O_FORMANT_5_PARA] +
			  out[synth.O_FORMANT_6_PARA] - out[synth.O_BYPASS_PARA] + special;

	  switch (mSynth.spkr.OS) {
		case 1:  
		case 2:
		case 3:	 output = out[mSynth.spkr.OS] +
				  0.99f * mSynth.state.integrator;
			 mSynth.state.integrator = output;
			 break;

		default:  output = out[mSynth.spkr.OS];
		          break;
	  }
	  return output;
	}

}
