package com.laps.jhlsyn;

import com.laps.jhlsyn.pogo.LLFrame;
import com.laps.jhlsyn.pogo.LLSynth;

public class frame {

	/*****************************************************************************/
	/** SenSyn - Version 2.2 **/
	/**                                                                         **/
	/** Copyright (c) 1991-1997 by Sensimetrics Corporation **/
	/** All rights reserved. **/
	/**                                                                         **/
	/*****************************************************************************/

	/*
	 * frame.c - synthesize one frame
	 * 
	 * Eric P. Carlson
	 * 
	 * Modification History:
	 * 
	 * 6 Oct 1997 reb: called InterPolePair rather than SetPolePair for nasal
	 * pole resonators. 30 Apr 1997 reb: used HLSYNAPI instead of FLAV_STDCALL.
	 * 27 Aug 1996 reb: include flavor.h, check FLAV_STCALL in def'n of
	 * LLSynthesize. 08 Aug 1996 reb: archived as version 2.2 (no changes). 27
	 * Mar 1995 Win32 MSVC version 29 Aug 1993 version 2.0 (library version) 23
	 * Feb 1993 changed casts in sigmx calculation, version 1.1 27 Feb 1992
	 * update formant_1s here, but DF1/DB1 pitch-synchronously 21 Nov 1991 moved
	 * spectral_tilt, formant_1s to be pitch-synchronous 5 Nov 1991 removed
	 * sample.c and init_syn.c, renamed to frame.c
	 */

	/* ---------------------------------------------------------------------- */

	static int LLSynthesize(LLSynth mSynth, LLFrame frame, short[] wave) {
		int index;
		int clip;
		double mSample;

		/* setup amplitudes */
		mSynth.coefs.asp_amp = frame.AH != 0 ? synth.dB2amp(mSynth.spkr.GH
				+ frame.AH + synth.A_AH) : 0;
		mSynth.coefs.fric_amp = frame.AF != 0 ? synth.dB2amp(mSynth.spkr.GF
				+ frame.AF + synth.A_AF) : 0;
		mSynth.coefs.f1p_amp = synth.dB2amp(synth.A_A1);
		mSynth.coefs.f2p_amp = synth.dB2amp(frame.A2F + synth.A_A2F);
		mSynth.coefs.f3p_amp = synth.dB2amp(frame.A3F + synth.A_A3F);
		mSynth.coefs.f4p_amp = synth.dB2amp(frame.A4F + synth.A_A4F);
		mSynth.coefs.f5p_amp = synth.dB2amp(frame.A5F + synth.A_A5F);
		mSynth.coefs.f6p_amp = synth.dB2amp(frame.A6F + synth.A_A6F);
		mSynth.coefs.bypass_amp = synth.dB2amp(frame.AB + synth.A_AB);
		mSynth.coefs.npv_amp = synth.dB2amp(frame.ANV + synth.A_ANV);
		mSynth.coefs.f1v_amp = synth.dB2amp(frame.A1V + synth.A_A1V);
		mSynth.coefs.f2v_amp = synth.dB2amp(frame.A2V + synth.A_A2V);
		mSynth.coefs.f3v_amp = synth.dB2amp(frame.A3V + synth.A_A3V);
		mSynth.coefs.f4v_amp = synth.dB2amp(frame.A4V + synth.A_A4V);
		mSynth.coefs.tpv_amp = synth.dB2amp(frame.ATV + synth.A_ATV);

		/* setup resonators */
		/* formant_1_cascade is also setup pitch-synchronously in voice.cpp */
		reson.InterPolePair(mSynth.formant_1_cascade, frame.F1
				+ (mSynth.state.glottis_open != 0 ? frame.DF1 : 0), frame.B1
				+ (mSynth.state.glottis_open != 0 ? frame.DB1 : 0),
				mSynth.spkr.SR);
		reson.InterPolePair(mSynth.formant_2_cascade, frame.F2, frame.B2,
				mSynth.spkr.SR);
		reson.InterPolePair(mSynth.formant_3_cascade, frame.F3, frame.B3,
				mSynth.spkr.SR);
		reson.SetPolePair(mSynth.formant_4_cascade, frame.F4, frame.B4,
				mSynth.spkr.SR);
		reson.SetPolePair(mSynth.formant_5_cascade, frame.F5, frame.B5,
				mSynth.spkr.SR);
		reson.SetPolePair(mSynth.formant_6_cascade, frame.F6, frame.B6,
				mSynth.spkr.SR);
		reson.SetPolePair(mSynth.formant_7_cascade, 6500, 500, mSynth.spkr.SR);
		reson.SetPolePair(mSynth.formant_8_cascade, 7500, 600, mSynth.spkr.SR);
		reson.InterPolePair(mSynth.nasal_pole_cascade, frame.FNP, frame.BNP,
				mSynth.spkr.SR);
		reson.SetZeroPair(mSynth.nasal_zero_cascade, frame.FNZ, frame.BNZ,
				mSynth.spkr.SR);
		reson.SetPolePair(mSynth.trach_pole_cascade, frame.FTP, frame.BTP,
				mSynth.spkr.SR);
		reson.SetZeroPair(mSynth.trach_zero_cascade, frame.FTZ, frame.BTZ,
				mSynth.spkr.SR);
		reson.InterPolePair(mSynth.formant_2_parallel, frame.F2, frame.B2F,
				mSynth.spkr.SR);
		reson.InterPolePair(mSynth.formant_3_parallel, frame.F3, frame.B3F,
				mSynth.spkr.SR);
		reson.SetPolePair(mSynth.formant_4_parallel, frame.F4, frame.B4F,
				mSynth.spkr.SR);
		reson.SetPolePair(mSynth.formant_5_parallel, frame.F5, frame.B5F,
				mSynth.spkr.SR);
		reson.SetPolePair(mSynth.formant_6_parallel, frame.F6, frame.B6F,
				mSynth.spkr.SR);
		reson.InterPolePair(mSynth.nasal_pole_special, frame.FNP, frame.BNP,
				mSynth.spkr.SR);
		/* formant_1_special is also setup pitch-synchronously in voice.cpp */
		reson.InterPolePair(mSynth.formant_1_special, frame.F1
				+ (mSynth.state.glottis_open != 0 ? frame.DF1 : 0), frame.B1
				+ (mSynth.state.glottis_open != 0 ? frame.DB1 : 0),
				mSynth.spkr.SR);
		reson.InterPolePair(mSynth.formant_2_special, frame.F2, frame.B2,
				mSynth.spkr.SR);
		reson.InterPolePair(mSynth.formant_3_special, frame.F3, frame.B3,
				mSynth.spkr.SR);
		reson.SetPolePair(mSynth.formant_4_special, frame.F4, frame.B4,
				mSynth.spkr.SR);
		reson.SetPolePair(mSynth.trach_pole_special, frame.FTP, frame.BTP,
				mSynth.spkr.SR);

		/* setup noise source */
		if (mSynth.spkr.SB != 0 && frame.AF == 0 && frame.AH == 0)
			mSynth.state.random = mSynth.spkr.RS;

		/* synthesize some samples */
		for (clip = 0, index = 0; index < mSynth.spkr.UI; index++) {
			mSample = sample.next_sample(mSynth, frame);
			if (mSample <= 32767)
				if (mSample >= -32768)
					wave[index] = (short) (mSample + 0.5); /*
															 * round, not
															 * truncate
															 */
				else {
					clip = 1;
					wave[index] = -32768;
				}
			else {
				clip = 1;
				wave[index] = 32767;
			}
		}

		return clip;
	}

}
