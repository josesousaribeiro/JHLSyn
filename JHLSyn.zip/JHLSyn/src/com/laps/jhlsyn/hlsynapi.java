package com.laps.jhlsyn;

import com.laps.jhlsyn.pogo.Speaker;

public class hlsynapi {
	/*****************************************************************************/
	/** HLsyn - Version 2.2 **/
	/**                                                                         **/
	/** Copyright (c) 1993-1999 by Sensimetrics Corporation **/
	/** All rights reserved. **/
	/**                                                                         **/
	/*****************************************************************************/

	/*
	 * HLSynAPI.h Include file defining the API for HLSyn.
	 * 
	 * 22 July 1999 R.E. Beaudoin Created.
	 */

	/*
	 * 1 13sep01 MFG Added new TSpeaker Structure for Hlysyn added also
	 * initDefaultSpeakerValues() and changeSpeakerValues() 2 31oct01 MFG Fixed
	 * the changespeakerValues so they switch between speakers properl 3 11jul02
	 * CAB Fixed #ifdef 4 19sep02 MFG Added support for new chris voice
	 */

	/* First come the HLSyn data structures ... */

	class HLFrame {
		double ag; /* mm^2 */
		double al; /* mm^2 */
		double ab; /* mm^2 */
		double an; /* mm^2 */
		double ue; /* cm^3/s */
		double f0; /* deciHz */
		double f1; /* Hz */
		double f2; /* Hz */
		double f3; /* Hz */
		double f4; /* Hz */
		double ps; /* cm H20 */
		double dc; /* % */
		double ap; /* mm^2 */
	}

	/*****
	 * All the areas in the state are in mm^2
	 *****/

	class HLState {
		double acl; /* area of liquid contraction, mm^2 */
		double acd; /* area of dorsum contraction, mm^2 */
		short loc; /* location of smallest contraction */
		double acx; /* area of smallest contraction, mm^2 */
		double agx; /* area of tracheal adjusted glottal contraction, mm^2 */
		double Pm; /* pressure in the mouth, dynes/cm^2 */
		double Pcw; /* pressure across the wall capacitance, dynes/cm^2 */
		double Ug; /* glottal flow, cm^3/s */
		double Uacx; /* flow across constriction (acx), cm^3/s */
		double Un; /* flow into the nose, cm^3/s */
		double Uw; /* flow into the parallel Rw, Cw branch (wall), cm^3/s */
		double f1c; /* f1 adjusted by constrictions, Hz */
		double f1x; /* f1 adjusted by constrictions and nose, Hz */
		double b1x; /* b1 adjusted by nose, Hz */
		double Cw; /* compliance of the pharyngeal walls (Cwm adjusted by dc) */
		double Cg; /* compliance of the glottis (Cgm adjusted by dc) */
		double agf; /* area of the glottis for calculating flow */
	};

	/*****
	 * This is a first pass at a nice way to use tables. An entry is typedef'ed
	 * and then each of the tables are defined with lengths and nmonics for the
	 * entries. NOTE: IT IS IMPORTANT THAT THE KNOWN ELEMENT IS COLUMN 1 AND THE
	 * UNKNOWN IS COLUMN 2. This is necessary when searching the tables.
	 *****/

	class TableRow {
		public double Column1;
		public double Column2;
	}

	public int MAXANFN = 9;
	double ANFN_AN;// Column1
	double ANFN_FN;// Column2;

	int MAXF1LOVERA = 11;
	double F1LOVERA_F1;// Column1
	double F1LOVERA_LOVERA;// Column2

	static int MAXANA = 6;
	double ANA_AN;// Column1
	double ANA_A;// Column2

	static int MAXANB = 6;
	double ANB_AN;// Column1
	double ANB_B;// Column2

	static int MAXF1C = 7;
	int F1C_F1; // Column1
	int F1C_C;// Column2

	static int MAXANK2 = 17;
	int ANK2_AN;// Column1
	double ANK2_K2;// Column2

	class FricativeGains {
		double A2F;
		double A3F;
		double A4F;
		double A5F;
		double AB;
	};

	/*****
	 * In this alveolar precompiler stuff I have set the important information
	 * which is the resolution and the f2,f3 mins and maxs. These are sufficient
	 * to compute everything else. I do however realize that the method used
	 * will run slowly because of the in-line divisions. I felt that
	 * precomputing the derived quantities would be leaving one open to errors.
	 * 
	 * The ranges are taken from the HLSYN write up as the ranges on the graphs
	 *****/
	static int ALV_RESOLUTION = 50; /* Hz */

	static int ALV_F2_MIN = 800; /* Hz */
	static int ALV_F2_MAX = 2900; /* Hz */
	static int ALV_F2_POINTS = (ALV_F2_MAX - ALV_F2_MIN) / ALV_RESOLUTION + 1;

	static int ALV_F3_MIN = 1800; /* Hz */
	static int ALV_F3_MAX = 3600; /* Hz */
	static int ALV_F3_POINTS = (ALV_F3_MAX - ALV_F3_MIN) / ALV_RESOLUTION + 1;

	FricativeGains ALVEOLAR(int F2, int F3) {
		return HLSpeaker.alveolar[(short) ( ((F2)-ALV_F2_MIN)/ALV_RESOLUTION )][(short) ( ((F3)-ALV_F3_MIN)/ALV_RESOLUTION )];
	}

	static class HLSpeaker {
		double Val;
		double Lc_al;
		double HelmholtzZeroAreaFrequency;

		double Vab;
		double Lc_ab;

		double f1Min;
		double f1Max;
		double f2RetroflexMax;
		double f3RetroflexMax;
		double f2LateralMax;
		double f3LateralMin;
		double Kacl;
		double aclFreq;

		double Vacd;
		double Lc_acd;
		double acdMax;
		double acd_f1Break;
		double KHi;
		double f1HiShift;

		double fno;

		double fm_f1BreakPoint;

		double BNZ_f1BreakPoint;

		double NasalBandwidth;
		double BNP_B1_anLow;
		double BNP_B1_anHigh;
		TableRow anaTable[] = new TableRow[MAXANA];
		TableRow anbTable[] = new TableRow[MAXANB];
		TableRow f1cTable[] = new TableRow[MAXF1C];
		double fp_f2BreakPoint;
		TableRow anK2Table[] = new TableRow[MAXANK2];
		double PharangealArea;

		double Cwm;
		double Rw;
		double Psm;
		double Cgm;
		double Lg;

		double NewtonInterpTimeStep;
		double UpdateInterval;

		double LabialAB;
		double PalVelarA2F;
		double PalVelarA5F;
		double PalVelarA3F;
		double PalVelar_f2Offset;
		double PalVelar_f2Overf3_Slope;
		double RetroflexA3F;
		double LateralA3F;
		public static FricativeGains alveolar[][] = new FricativeGains[ALV_F2_POINTS][ALV_F3_POINTS];
		double B2F;
		double B3F;
		double B4F;
		double B5F;

		double agm;
		double agAVModalOffsetMax;
		double agAVModalOffsetOnOff;
		double agMin;
		double agHiKLSourceCutoff;
		double AVPressureThreshold;
		double Kv;
		double KdAV0;
		double KdAV;
		double KdAV1;
		double Ka;

		double Kf;
		double AFInterpTimeStep;
		double AFThreshold;

		double OQm;
		double KOQ;
		double OQMax;
		double OQMin;

		double TLBreakArea;
		double KTL;
		double TLm;
		double SFromf4;
		double SDefault;
		double PctSfordBTL;
		double dBTLforPctS;
		double TLMax;
		double TLMin;

		double agDIMin;
		double KDI;

		double KdF;
		double F1T;

		double B1m;
		double B2m;
		double B3m;
		double B4m;
		double B5m;
		double KB1;
		double KB2;
		double KB3;
		double KB4;
		double KB5;

		double F5;

		double A6f;
		double F6;
		double B6F;

		double KCw;
		double KCg;
		double Kdf0dc;
		double Kpd;
		double Kf1;
		double f1_neutral;
		double KdPTdc;
		double f0_vowelshift_f1_break;
		double Lt;
		double At;
		double Lvg;
		double Lv;
		double Av;
		double Lhp;
		short ismale;
	}

	// #ifdef crazy

	/* Next come the LLSyn (Klatt-level) data structures.. */

	int NUM_OUTPUTS = 21;

	/* Synthesizer structure */
	class Synthesizer {
		/* static data */
		int parallel_only_flag;
		int num_casc_formants;
		int num_samples;
		int output_select;

		/* dynamic state data */
		int pulse_freq;
		int glottis_open;
		int period_ctr;
		int voicing_state;
		int pulse;
		int random;
		int voicing_time;
		long global_time;
		Float voicing_amp;
		Float glottal_state;
		Float asp_state;
		Float integrator;

		/* voicing state */
		int F_0;
		int FL;
		int OQ;
		int SQ;
		int Di;
		int Av;
		int Tl;
		int close_shortened;
		int close_time;
	}

	/* Coefficients structure */
	class Coefficients {
		double asp_amp;
		double fric_amp;
		double f1p_amp;
		double f2p_amp;
		double f3p_amp;
		double f4p_amp;
		double f5p_amp;
		double f6p_amp;
		double npv_amp;
		double f1v_amp;
		double f2v_amp;
		double f3v_amp;
		double f4v_amp;
		double tpv_amp;
		double bypass_amp;
	}

	class Resonator {
		Coef coef;
		State state;

		class Coef {
			double A, B, C;
		}

		class State {
			double Z1, Z2;
		}
	}

	class LLSynth {
		Synthesizer state;
		Coefficients coefs;
		Speaker spkr;
		Resonator glottal_pulse, spectral_tilt, nasal_pole_cascade,
				formant_1_cascade, formant_2_cascade, formant_3_cascade,
				formant_4_cascade, formant_5_cascade, formant_6_cascade,
				formant_7_cascade, formant_8_cascade, formant_2_parallel,
				formant_3_parallel, formant_4_parallel, formant_5_parallel,
				formant_6_parallel, trach_pole_cascade, formant_1_special,
				formant_2_special, formant_3_special, formant_4_special,
				nasal_pole_special, trach_pole_special;
		Resonator nasal_zero_cascade, trach_zero_cascade; /* anti-resonators */
		double out[] = new double[NUM_OUTPUTS];
	}

	class LLFrame {
		short F0;
		short AV;
		short OQ;
		short SQ;
		short TL;
		short FL;
		short DI;
		short AH;
		short AF;

		short F1;
		short B1;
		short DF1;
		short DB1;
		short F2;
		short B2;
		short F3;
		short B3;
		short F4;
		short B4;
		short F5;
		short B5;
		short F6;
		short B6;

		short FNP;
		short BNP;
		short FNZ;
		short BNZ;
		short FTP;
		short BTP;
		short FTZ;
		short BTZ;

		short A2F;
		short A3F;
		short A4F;
		short A5F;
		short A6F;
		short AB;
		short B2F;
		short B3F;
		short B4F;
		short B5F;
		short B6F;

		short ANV;
		short A1V;
		short A2V;
		short A3V;
		short A4V;
		short ATV;
	}

	int NUMSPEAKERS = 10;

	enum Speakers {
		Paul, Betty, Harry, Frank, Dennis, Kit, Ursula, Rita, Wendy, Ed, Matt, Sue, Mary, Lynn, Tom, Ivan, Charline, Arlene

	}





}
