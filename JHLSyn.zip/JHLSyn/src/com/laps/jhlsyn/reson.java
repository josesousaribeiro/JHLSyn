package com.laps.jhlsyn;

import com.laps.jhlsyn.pogo.Resonator;

public class reson {
	/*****************************************************************************/
	/**  SenSyn - Version 2.2                                                   **/
	/**                                                                         **/
	/**  Copyright (c) 1991-1996 by Sensimetrics Corporation                    **/
	/**  All rights reserved.                                                   **/
	/**                                                                         **/
	/*****************************************************************************/

	/*  reson.h - resonator declarations
	 *
	 *  coded by Eric P. Carlson, based upon reson.c by A.W. Howitt
	 *
	 *  Modification History:
	 *
	 *    10 Sep 1996  reb:  include flavor.h
	 *    03 Sep 1996  reb:  placed Float under control of 
	 *                       FLAV_FLOATTYPE_DOUBLE.
	 *    08 Aug 1996  reb:  changed type Float back to float (for Lisp 
	 *                       compatibility); archived as version 2.2.
	 *    20 Feb 1996  changed type Float back to double
	 *    22 Jul 1992  changed type Float back to float
	 *    26 Sep 1991  added AdvanceAntiResonator and InterPolePair
	 *    14 Nov 1991  changed type Float double
	 */


	

	

	 

	
	final static double PI = 3.1415926f;
	final static double MIN_RESON = 0.0001f;

	static void ClearResonator(Resonator theResonator)
	{
	  theResonator.getState().Z1 = 0.f;
	  theResonator.getState().Z2 = 0.f;
	}

	static double AdvanceResonator(Resonator theResonator, double input)
	  {
	  double StateZ1 = theResonator.getState().Z1;
	  double output = 
	    theResonator.getCoef().A * input
	    + theResonator.getCoef().B * StateZ1
	    + theResonator.getCoef().C * theResonator.getState().Z2;

	  if( Math.abs(output) < MIN_RESON )
	    output = 0.0f;
	  theResonator.getState().Z2 = StateZ1;
	  theResonator.getState().Z1 = output;
	  return output;
	  }

	static double AdvanceAntiResonator(Resonator theResonator, double input)
	  {
	  double StateZ1 = theResonator.getState().Z1;
	  double output = 
	    theResonator.getCoef().A * input
	    + theResonator.getCoef().B * StateZ1
	    + theResonator.getCoef().C * theResonator.getState().Z2;

	  theResonator.getState().Z2 = StateZ1;
	  theResonator.getState().Z1 = input;
	  return output;
	  }

	static void SetPolePair(Resonator theResonator, int CF, long l, int SF)
	{
	  double magnitude,angle,PiT;

	  PiT = PI / (double)SF;
	  magnitude = (double) Math.exp(-PiT * (double)l);
	  angle = 2.f * PiT * (double)CF;

	  theResonator.getCoef().C = (double)(-magnitude * magnitude);
	  theResonator.getCoef().B = (double)(magnitude * Math.cos(angle) * 2.f);
	  theResonator.getCoef().A = 1.f - theResonator.getCoef().B - theResonator.getCoef().C;
	  
	}

	static void InterPolePair(Resonator theResonator, int CF, int BW, int SF)
	{
	  double coefA, temp;

	  coefA = theResonator.getCoef().A;
	  SetPolePair(theResonator, CF, BW, SF);
	  if ((coefA != theResonator.getCoef().A) && coefA!=0) {
	    temp = (double) Math.sqrt(theResonator.getCoef().A / coefA);
	    theResonator.getState().Z1 *= temp;
	    theResonator.getState().Z2 *= temp;
	  }
	}

	static void SetZeroPair(Resonator theResonator, int CF, int BW, int SF)
	{
	  SetPolePair(theResonator,CF,BW,SF);
	  theResonator.getCoef().A = 1.f / theResonator.getCoef().A;
	  theResonator.getCoef().B *= -theResonator.getCoef().A;
	  theResonator.getCoef().C *= -theResonator.getCoef().A;
	}

}
